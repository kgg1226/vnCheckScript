﻿<#
======================================================================
 Windows 보안 점검·조치 통합 스크립트  (PC 정보 + 탐지 + 자동 조치 + 결과)
  - 한 번 실행으로: PC 정보 수집 → 보안 점검(탐지) → (동의 시) 저위험 항목 자동 조치
                    → 조치한 항목·내용 출력
  - 기준 : 주요정보통신기반시설 기술적 취약점 분석·평가(Windows) + KISA PC 점검
  - 대상 : Windows 10 / 11 (Home/Pro) / Server 2016+  (PowerShell 5.1 호환)
  - 실행 : 관리자 권한  /  보안점검조치_실행.bat 더블클릭
  - 권고 : UAC·디스크 암호화는 사용/데이터 영향이 있어 '권고'로만 표기(자동 조치 안 함)
  - 자동 적용 제외(권고/직접/담당자) : UAC, 디스크 암호화, 공유 삭제, 메신저, 무선랜,
                                      관리자 계정·그룹, RDP, 백신, Windows Update
======================================================================
#>
param(
  [switch]$Force,            # -Force : 이메일 질문도 건너뜀(완전 무인 실행용). 조치는 기본 자동 수행
  [switch]$CheckOnly,        # -CheckOnly : 점검만 하고 조치는 안 함(테스트용)
  [string]$OwnerEmail,       # 이 PC 사용자의 회사 이메일(자산 식별). 미지정 시 1회 질문/캐시
  [string]$SheetUrl,         # (선택) Google Apps Script 웹앱 URL — 결과를 구글 시트로 전송
  [string]$SheetToken        # (선택) 시트 전송 공유 토큰(스크립트와 동일해야 기록됨)
)

#====================== 사내 기준값 (필요 시 여기만 수정) ======================
$PolicyMaxPwAge  = 90
$PolicyMinPwLen  = 8        # 사내 기준 12자면 12로
$PolicyMinPwAge  = 1
$PolicyLockout   = 10       # 더 엄격히 하려면 5
$LockoutDuration = 30
$LockoutWindow   = 30
$BannerCaption   = "보안 공지"
$BannerText      = "본 PC는 회사 자산이며 무단 사용을 금합니다."
#==============================================================================

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " Windows 보안 점검 및 조치 (PC 정보 + 점검 + 자동 조치)" -ForegroundColor Cyan
Write-Host "  1) PC 정보 수집   2) 보안 점검(탐지)"
Write-Host "  3) 저위험 항목 자동 조치   4) 조치 결과 출력"
Write-Host "  * 변경 전 설정은 자동 백업됩니다. UAC/디스크 암호화는 권고만(자동 조치 안 함)."
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

#=== 구글 시트 전송 (선택): 아래 "" 안에 웹앱 URL 을 붙여넣으면 더블클릭만으로 전송됩니다 ===
if (-not $SheetUrl)   { $SheetUrl   = "" }   # ← 여기: "https://script.google.com/macros/s/AKfyc.../exec"
if (-not $SheetToken) { $SheetToken = "" }   # ← Apps Script 의 SHARED_TOKEN 과 동일(안 쓰면 비움)
#==============================================================================

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$ErrorActionPreference = 'Continue'
$script:PASS=0; $script:FAIL=0; $script:REC=0; $script:INFO=0
$script:applied=0; $script:failed=0
$script:items=@(); $script:fixlog=@(); $script:primaryIP=''; $script:primaryMAC=''

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) { Write-Host "관리자 권한이 필요합니다. '보안점검조치_실행.bat'으로 실행하세요." -ForegroundColor Red; exit 1 }

$ts     = Get-Date -Format 'yyyyMMdd_HHmmss'
$hostnm = $env:COMPUTERNAME
$arch   = $env:PROCESSOR_ARCHITECTURE
$base = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
try { $wt = Join-Path $base '.__wtest'; [IO.File]::WriteAllText($wt,'x'); Remove-Item $wt -Force -ErrorAction SilentlyContinue }
catch { $base = [Environment]::GetFolderPath('Desktop') }
$report    = Join-Path $base "WinSec_${hostnm}_${ts}.txt"
$backupDir = Join-Path $base "WinSec_백업_${hostnm}_${ts}"
$jsonPath  = Join-Path $base "WinSec_${hostnm}_${ts}.json"
if (Test-Path $report) { Remove-Item $report -Force -ErrorAction SilentlyContinue }

function Out-R { param([string]$t = "") Write-Host $t; Add-Content -Path $report -Value $t -Encoding UTF8 }
function Log   { param([string]$t = "") Out-R $t; if ($t -match '^\s+\[(적용|유지|실패)\]\s*(.+)$') { $script:fixlog += [pscustomobject]@{ status=$matches[1]; text=($matches[2]).Trim() } } }
function HR { Out-R "----------------------------------------------------------------------" }
function Section { param($t) Out-R ""; Out-R "==================== $t ===================="; Out-R "" }
function Get-SecVal { param($lines,$key)
  $m = $lines | Select-String "^\s*$key\s*=" | Select-Object -First 1
  if ($m) { ($m.Line -split '=',2)[1].Trim() } else { $null }
}
function RegVal { param($path,$name) (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue).$name }
function Shown($v) { if ($null -ne $v -and "$v" -ne "") { "$v" } else { "미설정" } }

function Set-RegValue {
  param($path,$name,$type,$value,$desc)
  try {
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    $cur = (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue).$name
    if ("$cur" -eq "$value") { Log "  [유지] $desc (이미 $value)"; return }
    New-ItemProperty -Path $path -Name $name -PropertyType $type -Value $value -Force | Out-Null
    $new = (Get-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue).$name
    if ("$new" -eq "$value") { Log "  [적용] $desc : '$(if($null -ne $cur){$cur}else{'없음'})' -> '$value'"; $script:applied++ }
    else { Log "  [실패] $desc (적용 후 값=$new)"; $script:failed++ }
  } catch { Log "  [실패] $desc : $($_.Exception.Message)"; $script:failed++ }
}

function Emit {
  param($id,$title,$result,$evidence,$basis,$fix)
  Out-R "######################################################################"
  Out-R "[ID]     : $id"
  Out-R "[항목]   : $title"
  Out-R "[Result] : $result"
  if ($evidence) { $ev=@($evidence); Out-R "[근거]   : $($ev[0])"; if ($ev.Count -gt 1) { $ev[1..($ev.Count-1)] | ForEach-Object { Out-R "           $_" } } }
  if ($basis)    { Out-R "[기준]   : $basis" }
  if ($fix)      { $fx=@($fix); Out-R "[조치]   : $($fx[0])";       if ($fx.Count -gt 1) { $fx[1..($fx.Count-1)] | ForEach-Object { Out-R "           $_" } } }
  $evj = if ($evidence) { (@($evidence) -join ' / ') } else { '' }
  $fxj = if ($fix)      { (@($fix) -join ' / ') } else { '' }
  $script:items += [pscustomobject]@{ id=$id; title=$title; result=$result; evidence=$evj; basis="$basis"; action=$fxj }
  switch ($result) {
    "양호" { $script:PASS++ }
    "취약" { $script:FAIL++ }
    "권고" { $script:REC++ }
    default { $script:INFO++ }
  }
  HR
}

function Save-Result {
  $pcObj = [ordered]@{
    hostname="$hostnm"; user="$env:USERNAME"
    manufacturer="$($cs.Manufacturer)"; model="$($cs.Model)"; serial="$($bios.SerialNumber)"
    cpu="$($cpu.Name)"; ramGB=$ramGB; diskGB=$diskGB; freeGB=$freeGB
    os="$($os.Caption)"; edition="$editionName"; build="$bld"; arch="$arch"
    domain=$(if($cs.PartOfDomain){"$($cs.Domain)"}else{"$($cs.Workgroup)"})
    lastBoot=$(if($os.LastBootUpTime){$os.LastBootUpTime.ToString('s')}else{''})
    installDate=$(if($os.InstallDate){$os.InstallDate.ToString('yyyy-MM-dd')}else{''})
    mfgDate="$mfgDate"
    ip="$script:primaryIP"; mac="$script:primaryMAC"
  }
  $obj = [ordered]@{
    schema='winsec/1'; collectedAt=(Get-Date -Format 's'); ownerEmail="$OwnerEmail"; token="$SheetToken"
    pc=$pcObj
    summary=[ordered]@{ pass=$script:PASS; vuln=$script:FAIL; rec=$script:REC; info=$script:INFO; applied=$script:applied; failed=$script:failed }
    items=@($script:items); remediation=@($script:fixlog)
  }
  $json = $obj | ConvertTo-Json -Depth 6
  try { $json | Out-File -FilePath $jsonPath -Encoding UTF8; Out-R " JSON 결과 : $jsonPath" } catch { Out-R " JSON 저장 실패 : $($_.Exception.Message)" }
  if ($SheetUrl) {
    try {
      $resp = Invoke-RestMethod -Uri $SheetUrl -Method Post -Body $json -ContentType 'application/json; charset=utf-8' -TimeoutSec 25
      if ("$resp" -match '"ok"\s*:\s*true' -or $resp.ok -eq $true) { Out-R " Google Sheet 전송 : 완료" }
      else { Out-R " Google Sheet 전송 실패 — 웹앱을 '모든 사용자' 접근으로 (재)배포했는지 확인하세요. JSON은 로컬에 저장됨" }
    } catch { Out-R " Google Sheet 전송 실패 : $($_.Exception.Message)" }
  }
}

$os    = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cv    = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction SilentlyContinue
$disp  = $cv.DisplayVersion; if (-not $disp) { $disp = $cv.ReleaseId }
$bld   = "$($cv.CurrentBuild).$($cv.UBR)"
$isHome = ($cv.EditionID -match 'Core') -or ($os.Caption -match 'Home')
$editionName = if ($cv.EditionID -match 'Enterprise' -or $os.Caption -match 'Enterprise') {'Enterprise'} elseif ($cv.EditionID -match 'Education') {'Education'} elseif ($cv.EditionID -match 'Pro' -or $os.Caption -match 'Pro') {'Pro'} elseif ($isHome) {'Home'} else {'기타'}

# 담당자(사용 PC 소유자) 이메일 — 자산 식별용 (1회 질문 후 owner.txt에 캐시)
$ownerFile = Join-Path $base 'owner.txt'
if (-not $OwnerEmail -and (Test-Path $ownerFile)) { try { $OwnerEmail = ((Get-Content $ownerFile -TotalCount 1)[0]).Trim() } catch {} }
if (-not $OwnerEmail -and -not $Force) {
  $OwnerEmail = (Read-Host "이 PC 사용자의 회사 이메일을 입력하세요 (예: hong@triplecomma.com / 모르면 그냥 Enter)").Trim()
  if ($OwnerEmail) { try { Set-Content -Path $ownerFile -Value $OwnerEmail -Encoding UTF8 } catch {} }
}

Out-R "======================================================================"
Out-R " Windows 보안 점검·조치 결과 (주정통 기술적 취약점 가이드 기준)"
Out-R " 호스트  : $hostnm   /   사용자 : $env:USERNAME"
Out-R " 점검시각: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Out-R " Windows : $($os.Caption) ($disp, build $bld) [$arch] / 에디션 $editionName"
Out-R "======================================================================"

#====================================================================== 0. PC 정보(자산)
Section "0. PC 정보 (자산)"
$cs   = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
$cpu  = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
$sd   = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'" -ErrorAction SilentlyContinue
$ramGB  = if ($cs.TotalPhysicalMemory) { [math]::Round($cs.TotalPhysicalMemory/1GB,1) } else { '?' }
$diskGB = if ($sd.Size) { [math]::Round($sd.Size/1GB,1) } else { '?' }
$freeGB = if ($sd.FreeSpace) { [math]::Round($sd.FreeSpace/1GB,1) } else { '?' }
$mfgDate = if ($bios.ReleaseDate) { $bios.ReleaseDate.ToString('yyyy-MM-dd') } else { '' }
Out-R ("  컴퓨터 이름   : {0}" -f $hostnm)
Out-R ("  제조사/모델   : {0} / {1}" -f $cs.Manufacturer, $cs.Model)
Out-R ("  시리얼 번호   : {0}" -f $bios.SerialNumber)
Out-R ("  CPU           : {0}" -f $cpu.Name)
Out-R ("  메모리(RAM)   : {0} GB" -f $ramGB)
Out-R ("  시스템 디스크 : {0} {1} GB (여유 {2} GB)" -f $env:SystemDrive, $diskGB, $freeGB)
Out-R ("  운영체제      : {0} ({1}, build {2}) [{3}] / {4}" -f $os.Caption, $disp, $bld, $arch, $editionName)
Out-R ("  도메인/그룹   : {0}" -f $(if($cs.PartOfDomain){"도메인 $($cs.Domain)"}else{"워크그룹 $($cs.Workgroup)"}))
Out-R ("  현재 사용자   : {0}" -f $env:USERNAME)
Out-R ("  마지막 부팅   : {0}" -f $(if($os.LastBootUpTime){$os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm')}else{'?'}))
Out-R ("  OS 설치일     : {0}" -f $(if($os.InstallDate){$os.InstallDate.ToString('yyyy-MM-dd')}else{'?'}))
Out-R ("  제조일(BIOS)  : {0}" -f $(if($mfgDate){$mfgDate}else{'확인 불가'}))
$nics = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True" -ErrorAction SilentlyContinue
foreach ($nc in @($nics)) {
  $ipv4 = @($nc.IPAddress | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' })
  if ($ipv4.Count -gt 0) {
    if (-not $script:primaryIP) { $script:primaryIP = "$($ipv4[0])"; $script:primaryMAC = "$($nc.MACAddress)" }
    Out-R ("  네트워크      : {0}" -f $nc.Description); Out-R ("                  IP {0} / MAC {1}" -f ($ipv4 -join ', '), $nc.MACAddress)
  }
}
HR

Out-R "[안내]  ※ 잘 모르겠으면 정보보호 담당자에게 문의하세요"
Out-R " 이 도구는 ① PC 정보 수집 → ② 보안 점검(탐지) → ③ 동의 시 저위험 항목 자동 조치"
Out-R " → ④ 조치한 항목·내용 출력 순으로 동작합니다."
Out-R " 각 항목 [조치] 줄 표시:"
Out-R "  · '자동 조치 ▶' : 이 도구가 곧바로 처리합니다 (아래 '조치 결과'에 적용 내역)."
Out-R "  · '직접 조치 ▶' : Windows '설정' 앱에서 적힌 순서(→)대로 바꿉니다."
Out-R "  · '권고 ▶'      : 사용/데이터 영향이 있어 자동 적용하지 않는 권고 항목입니다."
Out-R "  · '담당자 문의 ▶': 판단이 필요해 정보보호 담당자가 처리합니다."
Out-R "----------------------------------------------------------------------"
# 로컬 보안 정책 1회 추출(읽기 전용; secedit는 Home에서도 사용 가능)
$sec = $null
if ($admin) {
  try { $cfg = Join-Path $env:TEMP "secpol_$ts.cfg"; secedit /export /cfg $cfg /quiet 2>$null | Out-Null
        if (Test-Path $cfg) { $sec = Get-Content $cfg; Remove-Item $cfg -Force -ErrorAction SilentlyContinue } } catch {}
}

#====================================================================== 1. 계정 관리
Section "1. 계정 관리"

# PC-01 패스워드 최대 사용기간
$maxAge = if ($sec) { [int](Get-SecVal $sec 'MaximumPasswordAge') } else { $null }
if ($null -ne $maxAge) {
  $R = if ($maxAge -gt 0 -and $maxAge -le 90) {"양호"} else {"권고"}
  $ev = "최대 사용기간 = $(if($maxAge -le 0){"$maxAge (만료 안 함)"}else{"${maxAge}일"})"
} else { $R="정보"; $ev="secedit 읽기 실패(관리자 필요)" }
Emit "PC-01" "패스워드 최대 사용기간" $R $ev "강제 만료는 정책 사안이라 자동 적용하지 않음 (최신 가이드는 주기적 강제 만료 비권장 / ISMS-P 심사 기준에 따라 결정)" '권고 ▶ 패스워드 만료 주기는 사용 마찰이 있어 자동 적용하지 않습니다. 적용하려면 정보보호 담당자가 GPO/수동으로 (예: net accounts /maxpwage:90).'

# PC-02 패스워드 최소 길이 (길이만 — 복잡성과 분리)
$minLen = if ($sec) { [int](Get-SecVal $sec 'MinimumPasswordLength') } else { $null }
if ($null -ne $minLen) { $R = if ($minLen -ge 8) {"양호"} else {"취약"}; $ev="최소 암호 길이 = ${minLen}자" }
else { $R="정보"; $ev="secedit 읽기 실패(관리자 필요)" }
Emit "PC-02" "패스워드 최소 길이" $R $ev "8자 이상이면 양호 (사내 기준 12자 적용 시에도 충족 — 길이와 복잡성은 별도 항목)" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: net accounts /minpwlen:8 — 사내 기준 12자면 minpwlen:12)'

# ADD-05 패스워드 복잡성
$cplx = if ($sec) { Get-SecVal $sec 'PasswordComplexity' } else { $null }
if ($null -ne $cplx) { $R = if ($cplx -eq '1') {"양호"} else {"취약"}; $ev="PasswordComplexity = $cplx (1=사용,0=미사용)" }
else { $R="정보"; $ev="secedit 읽기 실패(관리자 필요)" }
$fixCplx = if ($isHome) { '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  [Home 에디션은 화면(그룹 정책)에서 켤 수 없어 자동 조치 도구 또는 담당자 적용이 필요합니다]' } else { '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  [Pro/Enterprise는 직접도 가능: secpol.msc → 암호 정책 → 암호는 복잡성을 만족해야 함 → 사용]' }
Emit "ADD-05" "패스워드 복잡성 설정" $R $ev "암호에 대/소문자·숫자·기호를 섞도록 강제하는 설정. 사용(1)이면 양호 (12자 이상 긴 정책이면 예외 검토 가능)" $fixCplx

# ADD-06 패스워드 최소 사용기간
$minAge = if ($sec) { [int](Get-SecVal $sec 'MinimumPasswordAge') } else { $null }
if ($null -ne $minAge) { $R = if ($minAge -ge 1) {"양호"} else {"취약"}; $ev="최소 사용기간 = ${minAge}일" }
else { $R="정보"; $ev="secedit 읽기 실패(관리자 필요)" }
Emit "ADD-06" "패스워드 최소 사용기간" $R $ev "암호를 바꾼 뒤 최소 며칠은 다시 못 바꾸게 막는 설정(옛 암호로 즉시 되돌리기 차단). 1일 이상이면 양호. ※ 매일 바꾸라는 뜻이 아닙니다" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: net accounts /minpwage:1)'

# ADD-07 계정 잠금 임계값
$lockout = if ($sec) { Get-SecVal $sec 'LockoutBadCount' } else { $null }
if ($null -ne $lockout) { $lc=[int]$lockout; $R = if ($lc -ge 1 -and $lc -le 10) {"양호"} else {"취약"}; $ev="잠금 임계값 = ${lc}회 (0=잠금 안 함)" }
else { $R="정보"; $ev="secedit 읽기 실패(관리자 필요)" }
Emit "ADD-07" "계정 잠금 임계값" $R $ev "암호를 정해진 횟수 틀리면 계정을 잠그는 설정. 1~10회면 양호 (주정통 권장 5회 이하·Windows 11 기본 10회). 0=무제한은 취약" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: net accounts /lockoutthreshold:10 /lockoutduration:30 /lockoutwindow:30)'

# ADD-08 해독 가능한 암호화로 암호 저장 해제
$clear = if ($sec) { Get-SecVal $sec 'ClearTextPassword' } else { $null }
if ($null -ne $clear) { $R = if ($clear -eq '0') {"양호"} else {"취약"}; $ev="ClearTextPassword(가역 암호화 저장) = $clear (0=해제)" }
else { $R="정보"; $ev="secedit 읽기 실패(관리자 필요)" }
Emit "ADD-08" "해독 가능한 암호화로 암호 저장 해제" $R $ev "해제(0)면 양호" '담당자 문의 ▶ 보통 기본값(해제)이라 조치 불필요. 만약 취약으로 나오면 정보보호 담당자에게 알리세요 (드문 경우)'

# ADD-03 Guest 계정 비활성화
try {
  $guest = Get-LocalUser -ErrorAction Stop | Where-Object { $_.SID.Value -like '*-501' } | Select-Object -First 1
  if ($guest -and -not $guest.Enabled) { $R="양호" } elseif ($guest) { $R="취약" } else { $R="정보" }
  $ev = if($guest){"Guest($($guest.Name)) 사용함=$($guest.Enabled)"}else{'Guest 계정 미확인'}
} catch { $R="정보"; $ev="Get-LocalUser 실패" }
Emit "ADD-03" "Guest 계정 비활성화" $R $ev "비활성화면 양호" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: net user guest /active:no)'

# ADD-09 Administrator 기본 계정 (이름 변경 / 비활성)  ※ Home 대응
try {
  $adm = Get-LocalUser -ErrorAction Stop | Where-Object { $_.SID.Value -like '*-500' } | Select-Object -First 1
  if (-not $adm) { $R="정보"; $ev="기본 관리자 계정 미확인" }
  elseif (-not $adm.Enabled) { $R="양호"; $ev="기본 관리자($($adm.Name)) 비활성 상태 (위험 낮음)" }
  elseif ($adm.Name -ieq 'Administrator') { $R="취약"; $ev="기본 관리자 계정이 'Administrator'(활성)" }
  else { $R="양호"; $ev="기본 관리자 계정 이름 변경됨($($adm.Name))" }
} catch { $R="정보"; $ev="Get-LocalUser 실패" }
$fixAdm = if ($isHome) { '담당자 문의 ▶ [Home] 보통 기본 관리자 계정이 꺼져 있어 조치 불필요. 켜져 있으면(취약) 정보보호 담당자에게 알리세요 — 비활성/이름변경은 담당자가 처리' } else { '담당자 문의 ▶ [Pro/Enterprise] 기본 관리자 계정 비활성/이름변경은 정보보호 담당자가 판단해 처리' }
Emit "ADD-09" "Administrator 기본 계정 이름 변경/비활성" $R $ev "기본 관리자 계정이 비활성이거나 이름이 변경되어 있으면 양호 (Home은 기본 비활성이면 충족)" $fixAdm

# ADD-10 관리자 그룹 최소 인원
try {
  $admins = @(Get-LocalGroupMember -SID 'S-1-5-32-544' -ErrorAction Stop | ForEach-Object { $_.Name })
  $ev = "Administrators 구성원 ($($admins.Count)명) → $($admins -join ', ')"
} catch { $ev = "Get-LocalGroupMember 실패 → net localgroup Administrators 확인" }
Emit "ADD-10" "관리자 그룹 최소 인원" "정보" $ev "관리자 권한 계정이 업무상 필요한 최소 인원이면 양호" '담당자 문의 ▶ 관리자 권한 계정 목록을 정보보호 담당자와 검토해 불필요한 계정을 일반 사용자로 변경'

#====================================================================== 2. 서비스 관리
Section "2. 서비스 관리"

# PC-03 공유 폴더 제거
try {
  $shares = @(Get-SmbShare -ErrorAction Stop | Where-Object { $_.Name -notmatch '\$$' })
  $R = if ($shares.Count -gt 0) {"취약"} else {"양호"}
  if ($shares.Count -gt 0) { $ev=@("기본 공유 외 공유 →"); $shares | ForEach-Object { $ev += "  - $($_.Name)  ($($_.Path))" } }
  else { $ev = "관리 기본 공유(C$, ADMIN$, IPC$) 외 공유 없음" }
} catch { $R="정보"; $ev="Get-SmbShare 실패 → net share 확인" }
Emit "PC-03" "공유 폴더 제거" $R $ev "업무에 불필요한 공유가 없으면 양호" '담당자 문의 ▶ 업무용 공유일 수 있어 자동 삭제하지 않습니다. 위 공유 목록을 정보보호 담당자와 확인 후 불필요한 것만 제거'

# PC-04 불필요한 서비스 제거 (서비스별 상태 + 위험 사유 근거)
$riskyList = @(
  @('TlntSvr','Telnet','평문 통신으로 자격증명·세션 노출'),
  @('RemoteRegistry','Remote Registry','원격에서 레지스트리 접근·변조 가능'),
  @('SNMP','SNMP Service','community string 등 시스템 정보 노출'),
  @('SharedAccess','ICS(인터넷 연결 공유)','비인가 네트워크 브리징·우회 경로'),
  @('RemoteAccess','라우팅 및 원격 액세스','불필요한 원격 접속·라우팅 경로'),
  @('simptcp','Simple TCP/IP Services','echo/chargen 등 DoS 악용·불필요'),
  @('FTPSVC','Microsoft FTP Service','평문 전송으로 자격증명 노출'),
  @('W3SVC','IIS(World Wide Web)','불필요 시 웹 공격면 증가')
)
$onSvc=@(); $onSvcName=@(); $svcDetail=@()
foreach ($r in $riskyList) {
  $svc = Get-Service -Name $r[0] -ErrorAction SilentlyContinue
  if ($svc) { $st="$($svc.Status)"; $svcDetail += "$($r[1]) [$st] — $($r[2])"; if ($st -eq 'Running') { $onSvc += $r[1]; $onSvcName += $r[0] } }
}
$R = if ($onSvc.Count -gt 0) {"취약"} else {"양호"}
if ($svcDetail.Count -gt 0) { $ev=@("점검 대상 서비스 상태 →"); $svcDetail | ForEach-Object { $ev += "  - $_" } }
else { $ev = "점검 대상 위험 서비스가 설치되어 있지 않음" }
if ($onSvc.Count -gt 0) { $ev += "▶ 실행 중(취약): $($onSvc -join ', ')" }
if ($onSvcName.Count -gt 0) {
  $fixPC04 = @("자동 조치 ▶ 이 도구가 아래 서비스를 자동 중지·해제합니다.  직접 하려면 관리자 PowerShell에 한 줄씩:")
  foreach ($n in $onSvcName) { $fixPC04 += "  Stop-Service $n -Force ; Set-Service $n -StartupType Disabled" }
} else { $fixPC04 = "조치 불필요 (실행 중인 위험 서비스 없음)" }
Emit "PC-04" "불필요한 서비스 제거" $R $ev "업무에 불필요한 위 서비스가 모두 중지(Stopped)면 양호. 실행 중이면 취약" $fixPC04

# ADD-04 SMBv1 비활성화
try {
  $smb1 = (Get-SmbServerConfiguration -ErrorAction Stop).EnableSMB1Protocol
  $R = if (-not $smb1) {"양호"} else {"취약"}; $ev="EnableSMB1Protocol = $smb1"
} catch { $R="정보"; $ev="Get-SmbServerConfiguration 실패(관리자 필요)" }
Emit "ADD-04" "SMBv1 비활성화" $R $ev "비활성(False)이면 양호 (랜섬웨어 EternalBlue 경로 차단)" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: 관리자 PowerShell에 Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force)'

# ADD-11 원격 데스크톱(RDP) 사용 제한  ※ Home 대응
$rdp = RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' 'fDenyTSConnections'
if ($rdp -eq 1 -or $null -eq $rdp) { $R="양호" } else { $R="정보" }
$ev = "fDenyTSConnections = $(Shown $rdp) (1=RDP 차단, 0=허용)"
$fixRdp = if ($isHome) { '담당자 문의 ▶ [Home] 원격 데스크톱 수신을 지원하지 않아 보통 자동 차단(양호). 별도 조치 불필요' } else { '담당자 문의 ▶ [Pro/Enterprise] 원격 데스크톱 사용 여부를 정보보호 담당자와 확인 후 처리' }
Emit "ADD-11" "원격 데스크톱(RDP) 사용 제한" $R $ev "RDP 미사용(차단)이면 양호. 사용 시 NLA·접속 계정 제한 등 보완통제 필요(정보)" $fixRdp

#====================================================================== 3. 패치 관리
Section "3. 패치 관리"

# PC-06 최신 보안 패치
$lastHF = $null
try {
  $safeHF = foreach ($h in (Get-HotFix -ErrorAction SilentlyContinue)) { $d=$null; try { $d=[datetime]$h.InstalledOn } catch {}; if ($d) { [pscustomobject]@{ HotFixID=$h.HotFixID; When=$d } } }
  $lastHF = $safeHF | Sort-Object When -Descending | Select-Object -First 1
} catch {}
Write-Host "  (Windows Update 미적용 항목 확인 중... 최대 90초)"
$pr = $null
try {
  $job = Start-Job -ScriptBlock {
    try { $s = New-Object -ComObject Microsoft.Update.Session
      $sr = $s.CreateUpdateSearcher().Search("IsInstalled=0 and Type='Software' and IsHidden=0")
      [pscustomobject]@{ ok=$true; cnt=$sr.Updates.Count; titles=@($sr.Updates | ForEach-Object { $_.Title }) }
    } catch { [pscustomobject]@{ ok=$false } } }
  if (Wait-Job $job -Timeout 90) { $pr = Receive-Job $job }
  Stop-Job $job -ErrorAction SilentlyContinue; Remove-Job $job -Force -ErrorAction SilentlyContinue
} catch {}
if ($pr -and $pr.ok) {
  $R = if ($pr.cnt -eq 0) {"양호"} else {"취약"}
  $ev = @("미적용 업데이트 = $($pr.cnt) 건")
  if ($pr.cnt -gt 0) { $pr.titles | Select-Object -First 8 | ForEach-Object { $ev += "  - $_" } }
  if ($lastHF) { $ev += "최근 적용 패치: $($lastHF.HotFixID) ($($lastHF.When.ToString('yyyy-MM-dd')))" }
} else { $R="정보"; $ev="Windows Update 스캔 실패/생략 (네트워크·WSUS 확인)" }
Emit "PC-06" "HOT FIX 등 최신 보안 패치 적용" $R $ev "미적용 보안 업데이트가 없으면 양호" '직접 조치 ▶ 설정 앱 열기 → Windows Update → 업데이트 확인 → 다운로드·설치 → PC 재시작'

# PC-07 최신 버전(빌드)
Emit "PC-07" "최신 서비스팩(버전/빌드) 적용" "정보" @("버전 $disp / 빌드 $bld","Windows 10/11은 서비스팩 대신 기능 업데이트(예: 24H2)를 사용") "사용 중인 기능 업데이트가 지원 종료(EOL) 전이면 양호 (버전 직접 확인)" '직접 조치 ▶ 설정 앱 → Windows Update → 업데이트 확인. 지원 종료된 버전이면 최신 버전으로 업그레이드'

# PC-08 / PC-09 백신
$avList = @(); try { $avList = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop) } catch {}
$mp = $null; try { $mp = Get-MpComputerStatus -ErrorAction Stop } catch {}
$thirdParty = @($avList | Where-Object { $_.displayName -notmatch 'Windows Defender|Microsoft Defender' })
if ($thirdParty.Count -gt 0) { $R="정보"; $ev="타사 백신 감지 → $((@($thirdParty.displayName)) -join ', ') (업데이트 상태는 해당 제품에서 확인)" }
elseif ($mp) { $R = if ($mp.AntivirusEnabled -and $mp.AntivirusSignatureAge -le 7) {"양호"} else {"취약"}; $ev="Defender 사용=$($mp.AntivirusEnabled) / 시그니처 경과일=$($mp.AntivirusSignatureAge)일 (최근갱신 $($mp.AntivirusSignatureLastUpdated))" }
else { $R="취약"; $ev="백신 제품 확인 실패" }
Emit "PC-08" "백신 설치 및 업데이트" $R $ev "백신 설치 + 시그니처 최신(7일 이내)이면 양호" '직접 조치 ▶ 시작 → Windows 보안 → 바이러스 및 위협 방지 → 백신 켜기·정의 업데이트 (타사 백신을 쓰면 그 제품에서)'

if ($thirdParty.Count -gt 0) { $R="정보"; $ev="타사 백신 → 실시간 감시 여부 해당 제품에서 확인" }
elseif ($mp) { $R = if ($mp.RealTimeProtectionEnabled) {"양호"} else {"취약"}; $ev="Defender 실시간 보호 = $($mp.RealTimeProtectionEnabled)" }
else { $R="취약"; $ev="실시간 감시 상태 확인 실패" }
Emit "PC-09" "백신 실시간 감시" $R $ev "실시간 감시가 켜져 있으면 양호" '직접 조치 ▶ 시작 → Windows 보안 → 바이러스 및 위협 방지 → 설정 관리 → 실시간 보호 켜기'

#====================================================================== 4. 로그 관리
Section "4. 로그 관리"

# ADD-12 감사 정책 설정
$ap = auditpol /get /category:* 2>$null
if ($ap) {
  $noA = @($ap | Select-String -Pattern "No Auditing|감사 안 함").Count
  $setN = @($ap | Select-String -Pattern "Success|Failure|성공|실패").Count
  $ev = @("감사 설정된 하위 범주 ${setN}개 / 감사 안 함 ${noA}개","핵심 권장: 계정 로그온·계정 관리·로그온/로그오프·정책 변경·권한 사용")
} else { $ev="auditpol 조회 실패(관리자 필요)" }
Emit "ADD-12" "감사 정책 설정" "정보" $ev "주요 이벤트(로그온·계정관리·정책변경 등) 감사가 설정되어 있으면 양호" '자동 조치 ▶ 이 도구가 핵심 감사 항목을 켭니다.  (직접: auditpol /set /category:* /success:enable /failure:enable — 로그가 많으면 핵심 범주만)'

#====================================================================== 5. 보안 관리
Section "5. 보안 관리"

# PC-10 OS 방화벽
try {
  $fw = @(Get-NetFirewallProfile -ErrorAction Stop); $offp = @($fw | Where-Object { -not $_.Enabled })
  $R = if ($fw.Count -gt 0 -and $offp.Count -eq 0) {"양호"} else {"취약"}
  $ev = @("프로필 상태 →"); $fw | ForEach-Object { $ev += "  - $($_.Name): $(if($_.Enabled){'켜짐'}else{'꺼짐'})" }
} catch { $R="정보"; $ev="Get-NetFirewallProfile 실패 → netsh advfirewall show allprofiles" }
Emit "PC-10" "OS 침입차단(방화벽) 활성화" $R $ev "모든 프로필(도메인/개인/공용)이 켜져 있으면 양호" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: netsh advfirewall set allprofiles state on)'

# PC-11 화면 보호기
$dk='HKCU:\Control Panel\Desktop'
$ssA=RegVal $dk 'ScreenSaveActive'; $ssT=RegVal $dk 'ScreenSaveTimeOut'; $ssS=RegVal $dk 'ScreenSaverIsSecure'
$toInt=0; if ($ssT) { [int]::TryParse("$ssT",[ref]$toInt) | Out-Null }
$R = if ($ssA -eq '1' -and $toInt -gt 0 -and $toInt -le 600 -and $ssS -eq '1') {"양호"} else {"취약"}
$ev = "사용=$(Shown $ssA) / 대기(초)=$(Shown $ssT) / 다시 시작 시 암호=$(Shown $ssS) (현재 사용자 기준)"
Emit "PC-11" "화면 보호기 설정(대기시간/암호)" $R $ev "화면 보호기 사용 + 대기 10분(600초) 이하 + 암호 보호면 양호" '직접 조치 ▶ 설정 → 개인 설정 → 잠금 화면 → 화면 보호기 설정: 보호기 지정 + 대기 10분 이하 + "다시 시작할 때 로그온 화면 표시" 체크'

# PC-12 이동식 미디어 자동실행 방지
$nd = RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoDriveTypeAutoRun'
$R = if ($nd -eq 255) {"양호"} else {"취약"}
$ev = "NoDriveTypeAutoRun = $(if($null -ne $nd){ '{0} (0x{0:X})' -f $nd }else{'미설정'})"
Emit "PC-12" "이동식 미디어 자동실행 방지" $R $ev "255(0xFF, 모든 드라이브 자동실행 차단)이면 양호" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f)'

# PC-13 비인가 무선랜
$wifi = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceDescription -match 'Wireless|Wi-Fi|802\.11|WLAN' })
if ($wifi.Count -eq 0) { $R="양호"; $ev="무선랜 어댑터 없음 (해당 없음)" }
else { $R="정보"; $ev=@("무선 어댑터 →"); $wifi | ForEach-Object { $ev += "  - $($_.Name) [$($_.Status)] $($_.InterfaceDescription)" } }
Emit "PC-13" "비인가 무선랜 사용 제한" $R $ev "무선랜 미사용 또는 인가된 AP에만 연결되어 있으면 양호" '직접 조치 ▶ 무선을 안 쓰면 설정 → 네트워크 및 인터넷에서 Wi-Fi 끄기. 쓰면 인가된 사내 Wi-Fi에만 연결'

# PC-05 상용 메신저 사용 금지
$uk = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
$apps = @(Get-ItemProperty $uk -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName -ErrorAction SilentlyContinue)
$msg = @($apps | Where-Object { $_ -match '카카오|Kakao|NateOn|네이트온|Line|라인|Telegram|Discord|Messenger' })
$ev = if($msg.Count -gt 0){"설치 감지 → $($msg -join ', ')"}else{'알려진 상용 메신저 미감지 (전체 목록 직접 검토)'}
Emit "PC-05" "상용 메신저 사용 금지" "정보" $ev "사내 정책상 금지된 메신저가 없으면 양호" '직접 조치 ▶ 설정 → 앱 → 설치된 앱 에서 사내 금지 메신저를 찾아 제거(삭제)'

# ADD-01 디스크 암호화 (BitLocker / 장치 암호화)  ※ Home 대응
try {
  $blv = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
  $R = if ($blv.ProtectionStatus -eq 'On') {"양호"} else {"권고"}
  $ev = "$($env:SystemDrive) 보호상태=$($blv.ProtectionStatus) / 암호화=$($blv.EncryptionPercentage)%"
} catch { $R="정보"; $ev="암호화 상태 확인 실패 (에디션·TPM 확인)" }
$fixEnc = '권고 ▶ 디스크 암호화는 복구 키를 잃으면 데이터가 잠길 수 있어, 보안 권고로 둡니다(자동 적용 안 함). 필요 시 정보보호 담당자가 정책·복구 키 관리와 함께 처리.' 
Emit "ADD-01" "디스크 암호화(BitLocker/장치 암호화)" $R $ev "시스템 드라이브가 암호화(보호=On)되어 있으면 양호 (분실·도난 1순위)" $fixEnc

# ADD-02 UAC
$lua = RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'EnableLUA'
$R = if ($lua -eq 1) {"양호"} else {"권고"}
Emit "ADD-02" "UAC(사용자 계정 컨트롤) 활성화" $R "EnableLUA = $(Shown $lua)" "EnableLUA = 1 이면 양호" '권고 ▶ UAC를 켜면 권한 요청(동의) 창 동작이 바뀌어 사용에 영향을 줄 수 있어, 보안 권고로 둡니다(자동 적용 안 함). 필요 시 정보보호 담당자가 처리.'

# ADD-13 마지막 로그온 사용자 이름 표시 안 함
$dl = RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'DontDisplayLastUserName'
$R = if ($dl -eq 1) {"양호"} else {"권고"}
Emit "ADD-13" "마지막 로그온 사용자 이름 표시 안 함" $R "DontDisplayLastUserName = $(Shown $dl)" "1이면 양호(단, 매 로그인 사용자명 직접 입력 필요)" '권고 ▶ 로그인마다 사용자명 입력이 생겨 자동 적용하지 않습니다. 필요 시 정보보호 담당자가 정책/수동으로.'

# ADD-14 익명 SID/이름 열거 제한
$ra = RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'RestrictAnonymous'
$ras = RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'RestrictAnonymousSAM'
$R = if ($ra -eq 1 -and $ras -eq 1) {"양호"} else {"취약"}
Emit "ADD-14" "익명 SID/이름 열거 제한" $R "RestrictAnonymous=$(Shown $ra) / RestrictAnonymousSAM=$(Shown $ras)" "둘 다 1이면 양호 (익명 계정/공유 열거 차단)" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v RestrictAnonymous /t REG_DWORD /d 1 /f ; 같은 경로에 RestrictAnonymousSAM 도 1)'

# ADD-15 로그온하지 않고 시스템 종료 허용 해제
$sw = RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'ShutdownWithoutLogon'
$R = if ($sw -eq 0) {"양호"} else {"취약"}
Emit "ADD-15" "로그온하지 않고 시스템 종료 허용 해제" $R "ShutdownWithoutLogon = $(Shown $sw) (0=해제)" "0이면 양호 (로그온 화면에서 종료 불가)" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ShutdownWithoutLogon /t REG_DWORD /d 0 /f)'

# ADD-16 로그온 경고 메시지(배너) 설정
$ln = RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'LegalNoticeText'
$R = if ($ln) {"양호"} else {"권고"}
Emit "ADD-16" "로그온 경고 메시지(배너) 설정" $R "LegalNoticeText = $(if($ln){'설정됨'}else{'미설정'})" "로그온 경고 문구가 설정되어 있으면 양호" '권고 ▶ 로그인마다 확인 클릭이 추가되어 자동 적용하지 않습니다. ISMS-P 고지 목적이면 정보보호 담당자가 정책으로 적용.'

# ADD-17 자동 로그온 해제
$aal = RegVal 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'AutoAdminLogon'
$R = if ($aal -eq '1') {"취약"} else {"양호"}
Emit "ADD-17" "자동 로그온 해제" $R "AutoAdminLogon = $(if($null -ne $aal){$aal}else{'미설정(해제)'})" "자동 로그온이 해제(0/미설정)면 양호" '자동 조치 ▶ 이 도구가 자동으로 처리합니다 (아래 조치 결과 참고).  (직접: reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon /t REG_SZ /d "0" /f)'


#--- 점검(탐지) 요약 ---
Out-R ""
Out-R "======================================================================"
Out-R " 점검(탐지) 요약 :  양호 $($script:PASS)  /  취약 $($script:FAIL)  /  권고 $($script:REC)  /  정보 $($script:INFO)"
Out-R "======================================================================"

#--- 조치 (기본: 묻지 않고 자동 조치 / -CheckOnly 면 점검만) ---
if ($CheckOnly) {
  Out-R ""
  Out-R "※ 점검만 수행(-CheckOnly). 조치는 건너뜁니다."
  Out-R " 결과 파일 : $report"
  Save-Result
  Write-Host ""
  Write-Host "점검만 완료(조치 안 함). 결과 파일: $report" -ForegroundColor Cyan
  exit 0
}
Write-Host ""
Write-Host "이어서 저위험 항목을 자동으로 조치합니다. (UAC·디스크 암호화 등 '권고'·업무 영향 항목 제외)" -ForegroundColor Yellow
Write-Host "변경 전 현재 설정은 다음 위치에 백업됩니다: $backupDir" -ForegroundColor Yellow
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
Section "조치 결과 (자동 적용 내역)"
# ---- 백업 ----
Log ""
Log "[백업] 현재 설정 저장 중..."
try { secedit /export /cfg (Join-Path $backupDir 'secpol_backup.cfg') /areas SECURITYPOLICY /quiet | Out-Null; Log "  - 계정 정책: secpol_backup.cfg" } catch { Log "  - 계정 정책 백업 실패: $($_.Exception.Message)" }
$bkKeys = @(
  'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System',
  'HKLM\SYSTEM\CurrentControlSet\Control\Lsa',
  'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon',
  'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer',
  'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server'
)
foreach ($k in $bkKeys) {
  $safe = ($k -replace '[\\:\s]','_')
  try { & reg export "$k" (Join-Path $backupDir "$safe.reg") /y *> $null; Log "  - 레지스트리: $safe.reg" } catch {}
}
Log "  ※ 롤백: 계정 정책은 secedit /configure /db sec.sdb /cfg secpol_backup.cfg /areas SECURITYPOLICY"
Log "          레지스트리는 해당 .reg 파일을 더블클릭(또는 reg import)으로 복원"
Log "          (새로 '생성'된 값은 reg import로 지워지지 않으니, 아래 변경 로그를 참고해 수동 삭제)"

#====================================================================== 1. 계정 정책
Log ""
Log "[1] 계정 정책"
try {
  & net accounts "/minpwlen:$PolicyMinPwLen" "/minpwage:$PolicyMinPwAge" | Out-Null
  Log "  [적용] 최소 길이 ${PolicyMinPwLen}자 / 최소 사용기간 ${PolicyMinPwAge}일 (만료 주기는 자동 미적용 — 권고)"
  $script:applied++
} catch { Log "  [실패] 패스워드 정책: $($_.Exception.Message)"; $script:failed++ }
try {
  & net accounts "/lockoutthreshold:$PolicyLockout" "/lockoutwindow:$LockoutWindow" "/lockoutduration:$LockoutDuration" | Out-Null
  Log "  [적용] 계정 잠금 임계값 ${PolicyLockout}회 / 지속 ${LockoutDuration}분 / 초기화 ${LockoutWindow}분"
  $script:applied++
} catch { Log "  [실패] 계정 잠금: $($_.Exception.Message)"; $script:failed++ }

# 패스워드 복잡성 (secedit) — net accounts로는 설정 불가
try {
  $cfg = Join-Path $env:TEMP "secfix_$ts.cfg"; $sdb = Join-Path $env:TEMP "secfix_$ts.sdb"
  secedit /export /cfg $cfg /areas SECURITYPOLICY /quiet | Out-Null
  if (Test-Path $cfg) {
    $lines = Get-Content $cfg -Encoding Unicode
    $now = ($lines | Select-String '^\s*PasswordComplexity\s*=' | Select-Object -First 1)
    if ($now -and $now.Line -match '=\s*1\s*$') { Log "  [유지] 패스워드 복잡성 (이미 사용)" }
    else {
      $out=@(); $done=$false
      foreach ($l in $lines) { if ($l -match '^\s*PasswordComplexity\s*=') { $out += 'PasswordComplexity = 1'; $done=$true } else { $out += $l } }
      if (-not $done) { $tmp=@(); foreach ($l in $out) { $tmp += $l; if ($l -match '^\[System Access\]') { $tmp += 'PasswordComplexity = 1' } }; $out=$tmp }
      $out | Set-Content $cfg -Encoding Unicode
      secedit /configure /db $sdb /cfg $cfg /areas SECURITYPOLICY /quiet | Out-Null
      Log "  [적용] 패스워드 복잡성 사용 (사용자 다음 암호 변경부터 적용)"; $script:applied++
    }
    Remove-Item $cfg,$sdb -Force -ErrorAction SilentlyContinue
  } else { Log "  [실패] 패스워드 복잡성: secedit export 실패"; $script:failed++ }
} catch { Log "  [실패] 패스워드 복잡성: $($_.Exception.Message)"; $script:failed++ }

# Guest 비활성화
try {
  $g = Get-LocalUser -ErrorAction Stop | Where-Object { $_.SID.Value -like '*-501' } | Select-Object -First 1
  if ($g -and $g.Enabled) { Disable-LocalUser -SID $g.SID -ErrorAction Stop; Log "  [적용] Guest 계정 비활성화"; $script:applied++ }
  elseif ($g) { Log "  [유지] Guest 계정 (이미 비활성)" }
} catch { Log "  [실패] Guest 비활성화: $($_.Exception.Message)"; $script:failed++ }

#====================================================================== 2. 불필요한 서비스
Log ""
Log "[2] 불필요한 서비스 중지·사용 안 함"
$svcList = @(
  @('TlntSvr','Telnet'), @('RemoteRegistry','Remote Registry'), @('SNMP','SNMP'),
  @('SharedAccess','ICS(인터넷 연결 공유)'), @('RemoteAccess','라우팅 및 원격 액세스'),
  @('simptcp','Simple TCP/IP'), @('FTPSVC','FTP'), @('W3SVC','IIS(웹)')
)
foreach ($s in $svcList) {
  try {
    $svc = Get-Service -Name $s[0] -ErrorAction SilentlyContinue
    if (-not $svc) { continue }
    $startType = (Get-CimInstance Win32_Service -Filter "Name='$($s[0])'" -ErrorAction SilentlyContinue).StartMode
    if ($svc.Status -ne 'Running' -and $startType -eq 'Disabled') { Log "  [유지] $($s[1]) (이미 중지·사용 안 함)"; continue }
    if ($svc.Status -eq 'Running') { Stop-Service -Name $s[0] -Force -ErrorAction SilentlyContinue }
    Set-Service -Name $s[0] -StartupType Disabled -ErrorAction Stop
    Log "  [적용] $($s[1]) 중지 + 사용 안 함"; $script:applied++
  } catch { Log "  [실패] $($s[1]): $($_.Exception.Message)"; $script:failed++ }
}
Log "  ※ SSDP Discovery / UPnP Device Host 는 무선 디스플레이·캐스팅 사용을 위해 끄지 않았습니다."

# SMBv1 비활성화
try {
  $smb1 = (Get-SmbServerConfiguration -ErrorAction Stop).EnableSMB1Protocol
  if ($smb1) { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop; Log "  [적용] SMBv1 비활성화"; $script:applied++ }
  else { Log "  [유지] SMBv1 (이미 비활성)" }
} catch { Log "  [실패] SMBv1: $($_.Exception.Message)"; $script:failed++ }

# 방화벽 모든 프로필 켜기
try {
  & netsh advfirewall set allprofiles state on | Out-Null
  Log "  [적용] 방화벽 모든 프로필 켜기"; $script:applied++
} catch { Log "  [실패] 방화벽: $($_.Exception.Message)"; $script:failed++ }

#====================================================================== 3. 감사 정책
Log ""
Log "[3] 감사 정책 (핵심 범주 성공·실패 기록)"
$auditCats = @(
  @('{69979850-797A-11D9-BED3-505054503030}','계정 로그온'),
  @('{6997984E-797A-11D9-BED3-505054503030}','계정 관리'),
  @('{69979849-797A-11D9-BED3-505054503030}','로그온/로그오프'),
  @('{6997984D-797A-11D9-BED3-505054503030}','정책 변경'),
  @('{69979848-797A-11D9-BED3-505054503030}','시스템')
)
foreach ($c in $auditCats) {
  try { & auditpol /set "/category:$($c[0])" /success:enable /failure:enable *> $null
        if ($LASTEXITCODE -eq 0) { Log "  [적용] 감사: $($c[1])"; $script:applied++ } else { Log "  [실패] 감사: $($c[1]) (코드 $LASTEXITCODE)"; $script:failed++ } }
  catch { Log "  [실패] 감사: $($c[1]) : $($_.Exception.Message)"; $script:failed++ }
}

#====================================================================== 4. 보안 옵션(레지스트리)
Log ""
Log "[4] 보안 옵션"
$P_SYS = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
$P_LSA = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
$P_WL  = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
$P_EXP = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'
Set-RegValue $P_LSA 'RestrictAnonymous'      'DWord'  1   '익명 열거 제한(RestrictAnonymous)'
Set-RegValue $P_LSA 'RestrictAnonymousSAM'   'DWord'  1   '익명 SAM 열거 제한(RestrictAnonymousSAM)'
Set-RegValue $P_SYS 'ShutdownWithoutLogon'   'DWord'  0   '로그온하지 않고 시스템 종료 허용 해제'
Set-RegValue $P_WL  'AutoAdminLogon'         'String' "0" '자동 로그온 해제'
Set-RegValue $P_EXP 'NoDriveTypeAutoRun'     'DWord'  255 '이동식 미디어 자동실행 차단'


#--- 자동 조치하지 않은 항목 ---
Out-R ""
Out-R "[자동 조치하지 않은 항목] (권고 / 직접 / 담당자 판단)"
Out-R "  · 권고  ─ 사용자 계정 컨트롤 UAC(ADD-02) : 켜면 권한 요청 창 동작이 바뀌어 사용 영향 — 권고로 둠"
Out-R "  · 권고  ─ 디스크 암호화(ADD-01)         : 복구 키를 잃으면 데이터 잠김 — 권고로 둠"
Out-R "  · 권고  ─ 패스워드 만료 주기(PC-01)     : 강제 만료는 사용 마찰 — 정책 결정(ISMS-P 기준 시 GPO)"
Out-R "  · 권고  ─ 마지막 사용자 숨김·로그온 배너(ADD-13·16) : 매 로그인 입력/클릭 추가 — 권고로 둠"
Out-R "  · 직접  ─ 보안 패치/버전(PC-06·07)      : 설정 > Windows Update 에서 설치"
Out-R "  · 직접  ─ 백신(PC-08·09)                : Windows 보안 > 바이러스 및 위협 방지"
Out-R "  · 직접  ─ 화면 보호기(PC-11)            : 설정 > 개인 설정 > 잠금 화면"
Out-R "  · 직접  ─ 상용 메신저(PC-05)            : 설정 > 앱 에서 제거"
Out-R "  · 담당자─ 공유 폴더(PC-03)·관리자 계정/그룹(ADD-09·10)·원격 데스크톱(ADD-11)·무선랜(PC-13)"

#--- 최종 요약 ---
Out-R ""
Out-R "======================================================================"
Out-R " 점검 :  양호 $($script:PASS) / 취약 $($script:FAIL) / 권고 $($script:REC) / 정보 $($script:INFO)"
Out-R " 조치 :  적용 $($script:applied) / 실패 $($script:failed)"
Out-R " 결과 파일 : $report"
Out-R " 백업 위치 : $backupDir"
Out-R "======================================================================"
Out-R " ▶ 다음 단계"
Out-R "   1) PC를 재부팅하세요 (레지스트리·정책 일부는 재부팅 후 적용)."
Out-R "   2) 이 도구를 다시 실행하면 조치 결과가 '양호'로 바뀌었는지 확인할 수 있습니다."
Out-R "   3) 문제가 생기면 백업 폴더의 .reg / secpol_backup.cfg 로 롤백하세요."
Save-Result
Write-Host ""
Write-Host "완료. 점검 양호 $($script:PASS)/취약 $($script:FAIL)/권고 $($script:REC) · 조치 적용 $($script:applied)/실패 $($script:failed)" -ForegroundColor Green
Write-Host "결과 파일: $report"
