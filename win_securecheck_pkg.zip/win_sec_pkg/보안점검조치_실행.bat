@echo off
chcp 949 >nul
title Windows Security Check and Remediation
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Administrator privileges required. Click [Yes] on the UAC prompt...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0win_sec.ps1"
echo.
pause
