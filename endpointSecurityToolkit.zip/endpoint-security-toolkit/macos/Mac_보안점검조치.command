#!/bin/bash
# ======================================================================
#  macOS 보안 점검·조치 통합 스크립트 (Mac 정보 + 탐지 + 자동 조치 + 결과)
#   - 한 번 실행으로: Mac 정보 → 보안 점검(탐지) → (동의 시) 저위험 항목 자동 조치
#                     → 조치한 항목·내용 출력  → 결과를 JSON 으로도 저장
#   - 권고 : FileVault(디스크 암호화)는 복구 키/데이터 영향이 있어 '권고'로만 표기(자동 조치 안 함)
#   - 결과를 엑셀로 취합(aggregate_to_excel.py) 하거나 구글 시트로 전송(--sheet-url) 가능
#   - 실행 : 더블클릭, 또는 터미널에서 옵션 지정
#       bash Mac_보안점검조치.command --email you@example.com \
#            --sheet-url "웹앱URL" --sheet-token "토큰" [--force]
#   - 대상 : macOS 13(Ventura)+ / Apple Silicon · Intel  (bash 3.2 호환)
# ======================================================================
cd "$(dirname "$0")" 2>/dev/null

# ---- 옵션 ----
FORCE=0; OWNER_EMAIL=""; SHEET_URL=""; SHEET_TOKEN=""; CHECK_ONLY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --force) FORCE=1;;
    --check-only) CHECK_ONLY=1;;
    --email) OWNER_EMAIL="$2"; shift;;
    --sheet-url) SHEET_URL="$2"; shift;;
    --sheet-token) SHEET_TOKEN="$2"; shift;;
  esac
  shift
done

#=== 구글 시트 설정은 같은 폴더의 sheet_config.txt 에서 읽습니다 (이 .command 는 편집하지 마세요) ===
SCRIPT_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
CFG="$SCRIPT_DIR/sheet_config.txt"
if [ -f "$CFG" ]; then
  [ -z "$SHEET_URL" ]   && SHEET_URL=$(sed -n 's/^[[:space:]]*SHEET_URL[[:space:]]*=[[:space:]]*//p'   "$CFG" | head -n1 | tr -d '\r')
  [ -z "$SHEET_TOKEN" ] && SHEET_TOKEN=$(sed -n 's/^[[:space:]]*SHEET_TOKEN[[:space:]]*=[[:space:]]*//p' "$CFG" | head -n1 | tr -d '\r')
fi

TS=$(date +%Y%m%d_%H%M%S)
HOSTN=$(scutil --get ComputerName 2>/dev/null || hostname)
USERN=$(stat -f%Su /dev/console 2>/dev/null || whoami)
OSVER=$(sw_vers -productVersion 2>/dev/null)
OSMAJ=$(echo "$OSVER" | cut -d. -f1)
OSBUILD=$(sw_vers -buildVersion 2>/dev/null)
OSNAME=$(sw_vers -productName 2>/dev/null)
TOOL_VERSION="1.0"        # 도구 버전 (Win·Mac 공통, 릴리스마다 갱신)
TOOL_BUILD="2026-06-30"   # 빌드 일자
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then CHIP="Apple Silicon"; APPLE_SILICON=1; else CHIP="Intel"; APPLE_SILICON=0; fi

DIR="$(pwd)"
REPORT="$DIR/MacSec_${HOSTN}_${TS}.txt"
JSONPATH="$DIR/MacSec_${HOSTN}_${TS}.json"
BACKUP="$DIR/MacSec_원복_${HOSTN}_${TS}.command"
if ! ( : > "$REPORT" ) 2>/dev/null; then DIR="$HOME/Desktop"; REPORT="$DIR/MacSec_${HOSTN}_${TS}.txt"; JSONPATH="$DIR/MacSec_${HOSTN}_${TS}.json"; BACKUP="$DIR/MacSec_원복_${HOSTN}_${TS}.command"; : > "$REPORT"; fi

out(){ printf '%s\n' "$*"; printf '%s\n' "$*" >> "$REPORT"; }
section(){ out ""; out "==================== $1 ===================="; out ""; }
json_escape(){ local s="$1"; s="${s//\\/\\\\}"; s="${s//\"/\\\"}"; s="${s//$'\n'/\\n}"; s="${s//$'\t'/\\t}"; s="${s//$'\r'/}"; printf '%s' "$s"; }

model_name() {
  # 모델 식별자 -> 사람이 읽는 정식 명칭. 표에 없으면 system_profiler 모델명+칩으로 폴백.
  local id="$1" name=""
  case "$id" in
    # MacBook Air (Apple Silicon)
    MacBookAir10,1) name="MacBook Air (M1, 2020)";;
    Mac14,2)  name="MacBook Air (M2, 2022)";;
    Mac14,15) name="MacBook Air (15-inch, M2, 2023)";;
    Mac15,12) name="MacBook Air (13-inch, M3, 2024)";;
    Mac15,13) name="MacBook Air (15-inch, M3, 2024)";;
    Mac16,12) name="MacBook Air (13-inch, M4, 2025)";;
    Mac16,13) name="MacBook Air (15-inch, M4, 2025)";;
    # MacBook Pro
    MacBookPro17,1) name="MacBook Pro (13-inch, M1, 2020)";;
    MacBookPro18,3|MacBookPro18,4) name="MacBook Pro (14-inch, M1 Pro/Max, 2021)";;
    MacBookPro18,1|MacBookPro18,2) name="MacBook Pro (16-inch, M1 Pro/Max, 2021)";;
    Mac14,7)  name="MacBook Pro (13-inch, M2, 2022)";;
    Mac14,5|Mac14,9)  name="MacBook Pro (14-inch, M2 Pro/Max, 2023)";;
    Mac14,6|Mac14,10) name="MacBook Pro (16-inch, M2 Pro/Max, 2023)";;
    Mac15,3)  name="MacBook Pro (14-inch, M3, 2023)";;
    Mac15,6|Mac15,8|Mac15,10) name="MacBook Pro (14-inch, M3 Pro/Max, 2023)";;
    Mac15,7|Mac15,9|Mac15,11) name="MacBook Pro (16-inch, M3 Pro/Max, 2023)";;
    Mac16,1)  name="MacBook Pro (14-inch, M4, 2024)";;
    # Mac mini
    Macmini9,1) name="Mac mini (M1, 2020)";;
    Mac14,3)  name="Mac mini (M2, 2023)";;
    Mac14,12) name="Mac mini (M2 Pro, 2023)";;
    Mac16,10) name="Mac mini (M4, 2024)";;
    Mac16,11) name="Mac mini (M4 Pro, 2024)";;
    # iMac
    iMac21,1|iMac21,2) name="iMac (24-inch, M1, 2021)";;
    Mac15,4|Mac15,5)   name="iMac (24-inch, M3, 2023)";;
    Mac16,2|Mac16,3)   name="iMac (24-inch, M4, 2024)";;
    # Mac Studio
    Mac13,1)  name="Mac Studio (M1 Max, 2022)";;
    Mac13,2)  name="Mac Studio (M1 Ultra, 2022)";;
    Mac14,13) name="Mac Studio (M2 Max, 2023)";;
    Mac14,14) name="Mac Studio (M2 Ultra, 2023)";;
  esac
  if [ -z "$name" ]; then
    local mn
    mn=$(system_profiler SPHardwareDataType 2>/dev/null | awk -F': ' '/Model Name/{print $2; exit}')
    if [ -n "$mn" ]; then name="$mn (${CPUNAME:-Apple})"; else name="$id"; fi
  fi
  printf '%s' "$name"
}

PASS=0; FAIL=0; REC=0; INFO=0; RECHG=0
IID=(); ITITLE=(); IRESULT=(); IEVID=(); IBASIS=(); IACTION=()
emit(){
  out "######################################################################"
  out "[ID]     : $1"
  out "[항목]   : $2"
  out "[Result] : $3"
  [ -n "$4" ] && out "[근거]   : $4"
  [ -n "$5" ] && out "[기준]   : $5"
  [ -n "$6" ] && out "[조치]   : $6"
  case "$3" in
    양호) PASS=$((PASS+1));;
    취약) FAIL=$((FAIL+1));;
    권고) REC=$((REC+1));;
    *)    INFO=$((INFO+1));;
  esac
  IID+=("$1"); ITITLE+=("$2"); IRESULT+=("$3"); IEVID+=("$4"); IBASIS+=("$5"); IACTION+=("$6")
  out "----------------------------------------------------------------------"
}

reassess(){
  # $1=id $2=새 결과 $3=새 근거 — 항목을 다시 읽어 결과/카운터 갱신
  local id="$1" nr="$2" nev="$3" i idx=-1
  for i in "${!IID[@]}"; do
    if [ "${IID[$i]}" = "$id" ]; then idx=$i; break; fi
  done
  [ "$idx" -lt 0 ] && return 0
  local old="${IRESULT[$idx]}" oldev="${IEVID[$idx]}"
  if [ "$old" != "$nr" ]; then
    case "$old" in 양호) PASS=$((PASS-1));; 취약) FAIL=$((FAIL-1));; 권고) REC=$((REC-1));; *) INFO=$((INFO-1));; esac
    case "$nr"  in 양호) PASS=$((PASS+1));; 취약) FAIL=$((FAIL+1));; 권고) REC=$((REC+1));; *) INFO=$((INFO+1));; esac
    out "  [$id] ${ITITLE[$idx]}"
    out "      조치 전 : $old  |  $oldev"
    out "      조치 후 : $nr  |  $nev"
    IRESULT[$idx]="$nr"
    [ -n "$nev" ] && IEVID[$idx]="[조치 전] $oldev  ->  [조치 후] $nev"
    RECHG=$((RECHG+1))
  fi
}

APPLIED=0; FAILED=0
FSTATUS=(); FTEXT=()
fixlog(){ out "  [$1] $2"; FSTATUS+=("$1"); FTEXT+=("$2"); case "$1" in 적용) APPLIED=$((APPLIED+1));; 실패) FAILED=$((FAILED+1));; esac; }
addback(){ printf '%s\n' "$*" >> "$BACKUP"; }

write_json(){
  {
    printf '{\n'
    printf '  "schema": "winsec/1",\n'
    printf '  "toolVersion": "%s",\n' "$TOOL_VERSION"
    printf '  "toolBuild": "%s",\n' "$TOOL_BUILD"
    printf '  "collectedAt": "%s",\n' "$(date +%Y-%m-%dT%H:%M:%S)"
    printf '  "ownerEmail": "%s",\n' "$(json_escape "$OWNER_EMAIL")"
    printf '  "token": "%s",\n' "$(json_escape "$SHEET_TOKEN")"
    printf '  "pc": {\n'
    printf '    "hostname": "%s",\n' "$(json_escape "$HOSTN")"
    printf '    "user": "%s",\n' "$(json_escape "$USERN")"
    printf '    "manufacturer": "Apple",\n'
    printf '    "model": "%s",\n' "$(json_escape "$MODEL_MKT")"
    printf '    "serial": "%s",\n' "$(json_escape "$SERIAL")"
    printf '    "cpu": "%s",\n' "$(json_escape "$CPUNAME")"
    printf '    "ramGB": %s,\n' "${RAMGB:-0}"
    printf '    "diskGB": %s,\n' "${DISKGB:-0}"
    printf '    "freeGB": %s,\n' "${FREEGB:-0}"
    printf '    "os": "%s",\n' "$(json_escape "$OSNAME $OSVER")"
    printf '    "edition": "%s",\n' "$(json_escape "$CHIP")"
    printf '    "build": "%s",\n' "$(json_escape "$OSBUILD")"
    printf '    "arch": "%s",\n' "$(json_escape "$ARCH")"
    printf '    "domain": "",\n'
    printf '    "lastBoot": "%s",\n' "$(json_escape "$LASTBOOT")"
    printf '    "installDate": "",\n'
    printf '    "ip": "%s",\n' "$(json_escape "$PRIMARY_IP")"
    printf '    "mac": "%s"\n' "$(json_escape "$PRIMARY_MAC")"
    printf '  },\n'
    printf '  "summary": { "pass": %d, "vuln": %d, "rec": %d, "info": %d, "applied": %d, "failed": %d },\n' "$PASS" "$FAIL" "$REC" "$INFO" "$APPLIED" "$FAILED"
    printf '  "items": [\n'
    local i n=${#IID[@]}
    for ((i=0;i<n;i++)); do
      printf '    {"id": "%s", "title": "%s", "result": "%s", "evidence": "%s", "basis": "%s", "action": "%s"}' \
        "$(json_escape "${IID[$i]}")" "$(json_escape "${ITITLE[$i]}")" "$(json_escape "${IRESULT[$i]}")" \
        "$(json_escape "${IEVID[$i]}")" "$(json_escape "${IBASIS[$i]}")" "$(json_escape "${IACTION[$i]}")"
      if [ $i -lt $((n-1)) ]; then printf ',\n'; else printf '\n'; fi
    done
    printf '  ],\n'
    printf '  "remediation": [\n'
    local m=${#FSTATUS[@]}
    for ((i=0;i<m;i++)); do
      printf '    {"status": "%s", "text": "%s"}' "$(json_escape "${FSTATUS[$i]}")" "$(json_escape "${FTEXT[$i]}")"
      if [ $i -lt $((m-1)) ]; then printf ',\n'; else printf '\n'; fi
    done
    printf '  ]\n'
    printf '}\n'
  } > "$JSONPATH"
  out " JSON 결과 : $JSONPATH"
  if [ -n "$SHEET_URL" ]; then
    RESP=$(curl -fsSL -m 25 -H "Content-Type: application/json; charset=utf-8" --data-binary @"$JSONPATH" "$SHEET_URL" 2>/dev/null)
    case "$RESP" in
      *'"ok":true'*) out " Google Sheet 전송 : 완료";;
      *) out " Google Sheet 전송 실패 — 웹앱을 '모든 사용자' 접근으로 (재)배포했는지 확인하세요. JSON은 로컬에 저장됨";;
    esac
  fi
}

# ---- 담당자 이메일 (자산 식별, 1회 질문 후 owner.txt 캐시) ----
OWNER_FILE="$DIR/owner.txt"
if [ -z "$OWNER_EMAIL" ] && [ -f "$OWNER_FILE" ]; then OWNER_EMAIL=$(head -n1 "$OWNER_FILE" | tr -d '\r\n'); fi
if [ -z "$OWNER_EMAIL" ] && [ "$FORCE" = "0" ]; then
  printf "이 Mac 사용자의 회사 이메일을 입력하세요 (예: you@example.com / 모르면 그냥 Enter): "
  read -r OWNER_EMAIL
  OWNER_EMAIL=$(printf '%s' "$OWNER_EMAIL" | tr -d '\r\n')
  [ -n "$OWNER_EMAIL" ] && printf '%s\n' "$OWNER_EMAIL" > "$OWNER_FILE"
fi

# ---- 관리자 권한 ----
echo ""
echo "일부 점검·조치는 관리자 권한이 필요합니다."
echo "암호를 물어보면 이 Mac의 로그인 암호를 입력하세요. (화면에 안 보이는 게 정상입니다)"
if sudo -v 2>/dev/null; then SUDO="sudo"; HAVE_SUDO=1; else SUDO=""; HAVE_SUDO=0; fi

out "======================================================================"
out " macOS 보안 점검·조치 결과"
out " 호스트  : $HOSTN   /   사용자 : $USERN"
out " 점검시각: $(date '+%Y-%m-%d %H:%M:%S')"
out " 도구버전: v$TOOL_VERSION  (빌드 $TOOL_BUILD)"
out " 시스템  : $OSNAME $OSVER (build $OSBUILD) [$CHIP / $ARCH]"
out "======================================================================"
[ "$HAVE_SUDO" = "0" ] && out "※ 관리자 권한 없음 — 원격 로그인/방화벽/파일 공유 등 일부 항목은 '정보'로 표시됩니다."

# ====================================================================== 0. Mac 정보
section "0. Mac 정보 (자산)"
MODEL=$(sysctl -n hw.model 2>/dev/null)
SERIAL=$(ioreg -c IOPlatformExpertDevice -d 2 2>/dev/null | awk -F'"' '/IOPlatformSerialNumber/{print $4}')
CPUNAME=$(sysctl -n machdep.cpu.brand_string 2>/dev/null)
MODEL_MKT=$(model_name "$MODEL")
MEMBYTES=$(sysctl -n hw.memsize 2>/dev/null)
RAMGB=$(awk -v b="${MEMBYTES:-0}" 'BEGIN{ if(b>0) printf "%.0f", b/1073741824; else print 0 }')
DISKLINE=$(df -k / 2>/dev/null | awk 'NR==2{print $2, $4}')
DISKGB=$(echo "$DISKLINE" | awk '{ if($1>0) printf "%.0f", $1/1048576; else print 0 }')
FREEGB=$(echo "$DISKLINE" | awk '{ if($2>0) printf "%.0f", $2/1048576; else print 0 }')
BOOTSEC=$(sysctl -n kern.boottime 2>/dev/null | sed -n 's/.*sec = \([0-9]*\).*/\1/p')
if [ -n "$BOOTSEC" ]; then LASTBOOT=$(date -r "$BOOTSEC" '+%Y-%m-%d %H:%M' 2>/dev/null); else LASTBOOT=""; fi
DEFIF=$(route -n get default 2>/dev/null | awk '/interface:/{print $2}')
[ -z "$DEFIF" ] && DEFIF="en0"
PRIMARY_IP=$(ipconfig getifaddr "$DEFIF" 2>/dev/null)
PRIMARY_MAC=$(ifconfig "$DEFIF" 2>/dev/null | awk '/ether/{print $2}')
out "  컴퓨터 이름   : $HOSTN"
out "  모델          : $MODEL_MKT  [$MODEL]"
out "  시리얼 번호   : ${SERIAL:-확인 불가}"
out "  칩/CPU        : ${CPUNAME:-확인 불가}"
out "  메모리(RAM)   : ${RAMGB} GB"
out "  시스템 디스크 : ${DISKGB} GB (여유 ${FREEGB} GB)"
out "  운영체제      : $OSNAME $OSVER (build $OSBUILD) [$ARCH]"
out "  현재 사용자   : $USERN"
out "  마지막 부팅   : ${LASTBOOT:-확인 불가}"
out "  네트워크      : $DEFIF  IP ${PRIMARY_IP:-없음} / MAC ${PRIMARY_MAC:-없음}"
out "----------------------------------------------------------------------"

out "[안내]  ※ 잘 모르겠으면 정보보호 담당자에게 문의하세요"
out " 이 도구는 ① Mac 정보 → ② 보안 점검 → ③ 동의 시 자동 조치 → ④ 조치 결과 순으로 동작합니다."
out " 각 항목 [조치] 줄 표시:"
out "  · '자동 조치 ▶' : 이 도구가 곧바로 처리합니다 (아래 '조치 결과'에 적용 내역)."
out "  · '직접 조치 ▶' : '시스템 설정' 앱에서 적힌 순서(→)대로 바꿉니다."
out "  · '권고 ▶'      : 사용/데이터 영향이 있어 자동 적용하지 않는 권고 항목입니다."
out "  · '담당자 문의 ▶': 판단이 필요해 정보보호 담당자가 처리합니다."
out "----------------------------------------------------------------------"

# ====================================================================== 1. 계정/로그인
section "1. 계정 / 로그인"

ASK=$(defaults -currentHost read com.apple.screensaver askForPassword 2>/dev/null)
[ -z "$ASK" ] && ASK=$(defaults read com.apple.screensaver askForPassword 2>/dev/null)
DLY=$(defaults -currentHost read com.apple.screensaver askForPasswordDelay 2>/dev/null)
if [ "$ASK" = "1" ]; then R="양호"; EV="화면 잠금 시 암호 요구함 (해제 지연 ${DLY:-0}초)"
elif [ "${OSMAJ:-0}" -ge 13 ]; then R="정보"; EV="화면 잠금 암호를 명령으로 확인 불가(macOS 13+). 시스템 설정 → 잠금 화면에서 직접 확인"
else R="취약"; EV="화면 잠금 시 암호 미요구 (askForPassword=${ASK:-미설정})"; fi
emit "MAC-01" "화면 잠금 시 암호 요구" "$R" "$EV" \
  "화면 보호기/잠자기에서 깨어날 때 암호를 묻게 하는 설정. 자리 비운 사이 무단 사용 차단. 암호 요구면 양호" \
  "화면 잠금 ▶ macOS 12 이하는 자동 적용, macOS 13+는 시스템 설정 → 잠금 화면 → '화면 보호기 시작/디스플레이 끈 후 암호 요구'를 '즉시'~'5초'로 직접 설정"

AL=$(defaults read /Library/Preferences/com.apple.loginwindow autoLoginUser 2>/dev/null)
if [ -n "$AL" ]; then R="취약"; EV="자동 로그인 켜짐 (사용자: $AL)"; else R="양호"; EV="자동 로그인 꺼짐"; fi
emit "MAC-02" "자동 로그인 비활성화" "$R" "$EV" \
  "전원을 켜면 암호 없이 바로 로그인되는 기능. 분실·도난 시 위험. 꺼져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 사용자 및 그룹 → 자동 로그인 끄기)"

GE=$(defaults read /Library/Preferences/com.apple.loginwindow GuestEnabled 2>/dev/null)
if [ "$GE" = "1" ]; then R="취약"; EV="게스트 계정 켜짐"; else R="양호"; EV="게스트 계정 꺼짐"; fi
emit "MAC-03" "게스트 계정 비활성화" "$R" "$EV" \
  "누구나 암호 없이 쓰는 손님 계정. 꺼져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 사용자 및 그룹 → 게스트 사용자 끄기)"

ADM=$(dscl . -read /Groups/admin GroupMembership 2>/dev/null | sed 's/GroupMembership://' | tr ' ' '\n' | grep -v '^root$' | grep -v '^$' | tr '\n' ' ')
emit "MAC-04" "관리자 계정 최소화" "정보" "관리자 계정: ${ADM:-확인 불가}" \
  "관리자 권한 계정이 많을수록 위험. 업무상 최소 인원이면 양호" \
  "담당자 문의 ▶ 관리자 계정 목록을 정보보호 담당자와 검토해 불필요한 계정을 표준 사용자로 변경"

# ====================================================================== 2. 시스템 보호
section "2. 시스템 보호"

FV=$(fdesetup status 2>/dev/null)
case "$FV" in
  *"FileVault is On"*)     R="양호"; EV="FileVault 켜짐 (디스크 암호화됨)";;
  *"Deferred enablement"*) R="정보"; EV="FileVault 활성화 예약됨 (다음 로그아웃/재시동 시 적용)";;
  *"FileVault is Off"*)    R="권고"; EV="FileVault 꺼짐 (디스크 미암호화 — 분실 시 데이터 노출)";;
  *)                       R="정보"; EV="FileVault 상태 확인 불가";;
esac
emit "MAC-05" "FileVault 디스크 암호화" "$R" "$EV" \
  "디스크 전체를 암호화해 분실·도난 시 데이터를 못 읽게 막는 보호. 켜져 있으면 양호" \
  "권고 ▶ 복구 키를 잃으면 데이터가 잠길 수 있어 자동 적용하지 않는 권고 항목입니다. 켜려면 시스템 설정 → 개인정보 보호 및 보안 → FileVault (복구 키 안전 보관)"

SIP=$(csrutil status 2>/dev/null)
case "$SIP" in
  *enabled*)  R="양호"; EV="SIP 활성화";;
  *disabled*) R="취약"; EV="SIP 비활성화 (시스템 핵심 파일 보호 꺼짐)";;
  *)          R="정보"; EV="SIP 상태 확인 불가";;
esac
emit "MAC-06" "시스템 무결성 보호(SIP)" "$R" "$EV" \
  "악성코드가 시스템 핵심 파일을 못 건드리게 막는 보호. 보통 기본 켜짐. 켜져 있으면 양호" \
  "담당자 문의 ▶ SIP 켜기는 복구 모드(재시동 중 전원 길게)에서 csrutil enable 필요 — 정보보호 담당자가 처리"

GK=$(spctl --status 2>/dev/null)
case "$GK" in
  *"assessments enabled"*)  R="양호"; EV="Gatekeeper 켜짐";;
  *"assessments disabled"*) R="취약"; EV="Gatekeeper 꺼짐 (서명 안 된 앱 무차별 허용)";;
  *)                        R="정보"; EV="Gatekeeper 상태 확인 불가";;
esac
emit "MAC-07" "Gatekeeper(앱 서명 검증)" "$R" "$EV" \
  "출처가 검증되지 않은 앱 실행을 막는 보호. 켜져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 개인정보 보호 및 보안 → 확인된 출처의 앱 허용)"

AC=$(defaults read /Library/Preferences/com.apple.SoftwareUpdate AutomaticCheckEnabled 2>/dev/null)
CI=$(defaults read /Library/Preferences/com.apple.SoftwareUpdate CriticalUpdateInstall 2>/dev/null)
AI=$(defaults read /Library/Preferences/com.apple.SoftwareUpdate AutomaticallyInstallMacOSUpdates 2>/dev/null)
if [ "$AC" = "1" ] && { [ "$CI" = "1" ] || [ "$AI" = "1" ]; }; then R="양호"; EV="자동 업데이트 켜짐 (확인=$AC, 보안설치=${CI:-0}, OS설치=${AI:-0})"
elif [ "$AC" = "1" ]; then R="정보"; EV="자동 확인은 켜졌으나 자동 설치 일부 꺼짐 (확인=$AC, 보안설치=${CI:-0})"
else R="취약"; EV="자동 업데이트 꺼짐 (AutomaticCheckEnabled=${AC:-미설정})"; fi
emit "MAC-08" "자동 보안 업데이트" "$R" "$EV" \
  "보안 패치를 자동으로 확인·설치하는 설정(대규모 OS 업그레이드와는 별개). 켜져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 일반 → 소프트웨어 업데이트 → 자동 업데이트 켜기)"

if [ "$APPLE_SILICON" = "1" ]; then
  R="정보"; EV="Apple Silicon — 기본 보안 부팅 적용, 별도 펌웨어 암호 항목 해당 없음"; FIX="해당 없음 (Apple Silicon은 보안 부팅이 기본 적용)"
elif [ "$HAVE_SUDO" = "1" ]; then
  FP=$($SUDO firmwarepasswd -check 2>/dev/null)
  case "$FP" in *Yes*) R="양호"; EV="펌웨어 암호 설정됨";; *No*) R="정보"; EV="펌웨어 암호 미설정 (Intel Mac 권장)";; *) R="정보"; EV="펌웨어 암호 확인 불가";; esac
  FIX="담당자 문의 ▶ (Intel Mac) 펌웨어 암호는 복구 모드에서 설정 — 정보보호 담당자가 처리"
else
  R="정보"; EV="펌웨어 암호 확인엔 관리자 권한 필요"; FIX="담당자 문의 ▶ (Intel Mac) 복구 모드에서 펌웨어 암호 설정"
fi
emit "MAC-16" "펌웨어/복구 보호" "$R" "$EV" "허가 없이 외부 디스크 부팅·복구 모드 진입을 막는 보호" "$FIX"

# ====================================================================== 3. 네트워크/공유
section "3. 네트워크 / 공유"

FW=$($SUDO /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>/dev/null)
case "$FW" in
  *"State = 1"*|*"State = 2"*) R="양호"; EV="방화벽 켜짐";;
  *"State = 0"*)               R="취약"; EV="방화벽 꺼짐";;
  *)
    FWD=$(defaults read /Library/Preferences/com.apple.alf globalstate 2>/dev/null)
    case "$FWD" in 1|2) R="양호"; EV="방화벽 켜짐 (globalstate=$FWD)";; 0) R="취약"; EV="방화벽 꺼짐";; *) R="정보"; EV="방화벽 상태 확인 불가";; esac;;
esac
emit "MAC-09" "방화벽 활성화" "$R" "$EV" \
  "외부에서 들어오는 불필요한 접속을 막는 1차 차단막. 켜져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 네트워크 → 방화벽 → 켜기)"

if [ "$HAVE_SUDO" = "1" ]; then
  SSH=$($SUDO systemsetup -getremotelogin 2>/dev/null)
  case "$SSH" in *On*) R="취약"; EV="원격 로그인(SSH) 켜짐";; *Off*) R="양호"; EV="원격 로그인(SSH) 꺼짐";; *) R="정보"; EV="원격 로그인 상태 확인 불가";; esac
else R="정보"; EV="원격 로그인 확인엔 관리자 권한 필요"; fi
emit "MAC-10" "원격 로그인(SSH) 비활성화" "$R" "$EV" \
  "다른 컴퓨터에서 터미널로 이 Mac에 접속하게 하는 기능. 안 쓰면 꺼야 안전. 꺼져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 일반 → 공유 → 원격 로그인 끄기)"

if [ -e "/Library/Application Support/Apple/Remote Desktop/RemoteManagement.launchd" ]; then R="취약"; EV="원격 관리(ARD) 활성화"; else R="양호"; EV="원격 관리(ARD) 비활성화"; fi
emit "MAC-11" "원격 관리(ARD) 비활성화" "$R" "$EV" \
  "다른 컴퓨터가 이 Mac 화면을 보고 조작하게 하는 기능. 안 쓰면 꺼야 안전. 꺼져 있으면 양호" \
  "자동 조치 ▶ 이 도구가 자동으로 처리합니다.  (직접: 시스템 설정 → 일반 → 공유 → 원격 관리 끄기)"

if [ "$HAVE_SUDO" = "1" ]; then
  if $SUDO launchctl list 2>/dev/null | grep -q "com.apple.smbd"; then R="정보"; EV="파일 공유(SMB) 켜짐"; else R="양호"; EV="파일 공유(SMB) 꺼짐"; fi
else R="정보"; EV="파일 공유 확인엔 관리자 권한 필요"; fi
emit "MAC-12" "파일 공유(SMB) 점검" "$R" "$EV" \
  "이 Mac의 폴더를 네트워크에 공유하는 기능. 복합기 스캔→폴더 등 업무에 필요할 수 있어 일괄 차단하지 않습니다" \
  "담당자 문의 ▶ 업무에 필요 없으면 시스템 설정 → 일반 → 공유 → 파일 공유 끄기. 필요하면 담당자와 예외처리(공유 범위·계정 최소화)"

NAT=$(defaults read /Library/Preferences/SystemConfiguration/com.apple.nat NAT 2>/dev/null | grep -i "Enabled = 1")
if [ -n "$NAT" ]; then R="취약"; EV="인터넷 공유 켜짐"; else R="양호"; EV="인터넷 공유 꺼짐"; fi
emit "MAC-13" "인터넷 공유 비활성화" "$R" "$EV" \
  "이 Mac의 인터넷을 다른 기기에 나눠주는 기능(비인가 네트워크 우회 경로). 꺼져 있으면 양호" \
  "직접 조치 ▶ 시스템 설정 → 일반 → 공유 → 인터넷 공유 끄기 (보통 기본으로 꺼져 있습니다)"

# ====================================================================== 4. 데이터/기타
section "4. 데이터 / 기타"

if nvram -p 2>/dev/null | grep -qi "fmm-mobileme-token"; then R="양호"; EV="나의 Mac 찾기 켜짐(추정)"; else R="정보"; EV="나의 Mac 찾기 상태 — 시스템 설정에서 직접 확인 권장"; fi
emit "MAC-14" "나의 Mac 찾기(Find My)" "$R" "$EV" \
  "분실 시 위치 찾기·원격 잠금·삭제가 가능한 기능. 켜져 있으면 양호" \
  "직접 조치 ▶ 시스템 설정 → [상단 Apple 계정] → iCloud → 나의 Mac 찾기 → 켜기"

if tmutil destinationinfo 2>/dev/null | grep -qi "Name"; then R="정보"; EV="Time Machine 백업 대상 설정됨"; else R="정보"; EV="Time Machine 백업 미설정"; fi
emit "MAC-15" "Time Machine 백업" "$R" "$EV" \
  "랜섬웨어·고장 대비 자동 백업. 백업 대상이 설정돼 정기 백업되면 양호" \
  "직접 조치 ▶ 외장 디스크 연결 후 시스템 설정 → 일반 → Time Machine → 백업 디스크 추가"

# ---- 점검 요약 ----
out ""
out "======================================================================"
out " 점검(탐지) 요약 :  양호 $PASS  /  취약 $FAIL  /  권고 $REC  /  정보 $INFO"
out "======================================================================"

# ---- 조치 (기본: 묻지 않고 자동 조치 / --check-only 면 점검만) ----
if [ "$CHECK_ONLY" = "1" ]; then
  out ""
  out "※ 점검만 수행(--check-only). 조치는 건너뜁니다."
  write_json
  echo ""
  echo "점검만 완료(조치 안 함)."
  echo "  결과: $REPORT"
  echo "  JSON: $JSONPATH"
  exit 0
fi
out ""
out "이어서 저위험 항목을 자동으로 조치합니다. (FileVault 등 '권고'·업무 영향 항목은 제외)"
out "변경 전 현재 설정은 원복 파일로 백업됩니다: $BACKUP"

# ---- 조치 ----
echo '#!/bin/bash' > "$BACKUP"
echo '# 이 스크립트를 실행하면 변경 전 상태로 되돌립니다. (더블클릭 또는 bash 실행, 암호 필요)' >> "$BACKUP"
echo 'echo "원복을 시작합니다. 암호를 물어보면 입력하세요."; sudo -v || exit 1' >> "$BACKUP"
chmod +x "$BACKUP" 2>/dev/null

section "조치 결과 (자동 적용 내역)"

# 화면 잠금 즉시 암호 (현재 사용자)
if [ "${OSMAJ:-0}" -ge 13 ]; then
  fixlog "안내" "화면 잠금 암호는 명령 적용이 제한됩니다(macOS 13+). 시스템 설정 → 잠금 화면 → '화면 보호기 시작/디스플레이 끈 후 암호 요구'를 '즉시'~'5초'로 설정하세요"
else
  cur=$(defaults read com.apple.screensaver askForPassword 2>/dev/null); curd=$(defaults read com.apple.screensaver askForPasswordDelay 2>/dev/null)
  if [ -n "$cur" ]; then addback "defaults write com.apple.screensaver askForPassword -int $cur"; else addback "defaults delete com.apple.screensaver askForPassword 2>/dev/null"; fi
  if [ -n "$curd" ]; then addback "defaults write com.apple.screensaver askForPasswordDelay -int $curd"; else addback "defaults delete com.apple.screensaver askForPasswordDelay 2>/dev/null"; fi
  defaults write com.apple.screensaver askForPassword -int 1 2>/dev/null
  defaults write com.apple.screensaver askForPasswordDelay -int 60 2>/dev/null
  fixlog "적용" "화면 잠금 시 암호 요구 (60초 유예 후)"
fi

# 자동 로그인 끄기
cural=$($SUDO defaults read /Library/Preferences/com.apple.loginwindow autoLoginUser 2>/dev/null)
if [ -n "$cural" ]; then
  addback "sudo defaults write /Library/Preferences/com.apple.loginwindow autoLoginUser -string $cural"
  $SUDO defaults delete /Library/Preferences/com.apple.loginwindow autoLoginUser 2>/dev/null
  $SUDO rm -f /etc/kcpassword 2>/dev/null
  fixlog "적용" "자동 로그인 끄기 (이전: $cural)"
else fixlog "유지" "자동 로그인 (이미 꺼짐)"; fi

# 게스트 계정 끄기
curg=$($SUDO defaults read /Library/Preferences/com.apple.loginwindow GuestEnabled 2>/dev/null)
if [ -n "$curg" ]; then addback "sudo defaults write /Library/Preferences/com.apple.loginwindow GuestEnabled -int $curg"; else addback "sudo defaults delete /Library/Preferences/com.apple.loginwindow GuestEnabled 2>/dev/null"; fi
$SUDO defaults write /Library/Preferences/com.apple.loginwindow GuestEnabled -bool false 2>/dev/null
$SUDO sysadminctl -guestAccount off 2>/dev/null
fixlog "적용" "게스트 계정 끄기"

# Gatekeeper 켜기
curgk=$(spctl --status 2>/dev/null)
case "$curgk" in
  *enabled*) fixlog "유지" "Gatekeeper (이미 켜짐)";;
  *)
    if [ "${OSMAJ:-0}" -ge 15 ]; then
      fixlog "안내" "Gatekeeper: macOS 15+는 명령(spctl)으로 켤 수 없습니다. 시스템 설정 → 개인정보 보호 및 보안 → 보안에서 'App Store와 인증된 개발자' 선택"
    else
      case "$curgk" in *disabled*) addback "sudo spctl --master-disable";; esac
      if $SUDO spctl --master-enable >/dev/null 2>&1; then fixlog "적용" "Gatekeeper 켜기"; else fixlog "실패" "Gatekeeper"; fi
    fi;;
esac

# 자동 보안 업데이트 켜기
for kv in AutomaticCheckEnabled AutomaticDownload CriticalUpdateInstall ConfigDataInstall; do
  c=$($SUDO defaults read /Library/Preferences/com.apple.SoftwareUpdate "$kv" 2>/dev/null)
  if [ -n "$c" ]; then addback "sudo defaults write /Library/Preferences/com.apple.SoftwareUpdate $kv -int $c"; else addback "sudo defaults delete /Library/Preferences/com.apple.SoftwareUpdate $kv 2>/dev/null"; fi
  $SUDO defaults write /Library/Preferences/com.apple.SoftwareUpdate "$kv" -bool true 2>/dev/null
done
fixlog "적용" "자동 보안 업데이트 켜기"

# 방화벽 켜기 + 스텔스
curfw=$($SUDO /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>/dev/null)
case "$curfw" in *"State = 0"*) addback "sudo /usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate off";; esac
$SUDO /usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate on >/dev/null 2>&1
$SUDO /usr/libexec/ApplicationFirewall/socketfilterfw --setstealthmode on >/dev/null 2>&1
fixlog "적용" "방화벽 켜기 + 스텔스 모드"

# 원격 로그인(SSH) 끄기
curssh=$($SUDO systemsetup -getremotelogin 2>/dev/null); case "$curssh" in *On*) addback "sudo systemsetup -f -setremotelogin on";; esac
if $SUDO systemsetup -f -setremotelogin off >/dev/null 2>&1; then fixlog "적용" "원격 로그인(SSH) 끄기"; else fixlog "유지" "원격 로그인"; fi

# 원격 관리(ARD) 끄기
if [ -e "/Library/Application Support/Apple/Remote Desktop/RemoteManagement.launchd" ]; then
  $SUDO /System/Library/CoreServices/RemoteManagement/ARDAgent.app/Contents/Resources/kickstart -deactivate -stop >/dev/null 2>&1
  fixlog "적용" "원격 관리(ARD) 끄기 (필요 시 시스템 설정에서 다시 켜기)"
else fixlog "유지" "원격 관리(ARD) (이미 꺼짐)"; fi

# ---- 조치 후 재점검 (자동 — 최종 상태 반영) ----
section "조치 전후 비교 (자동 재점검 — 최종 상태 반영)"
out "[재점검] 조치한 항목을 다시 읽어 '조치 전 -> 조치 후'로 비교합니다. (최종 판정은 조치 후 기준)"
AL2=$(defaults read /Library/Preferences/com.apple.loginwindow autoLoginUser 2>/dev/null)
[ -z "$AL2" ] && reassess "MAC-02" "양호" "자동 로그인 꺼짐(조치 후)"
GE2=$(defaults read /Library/Preferences/com.apple.loginwindow GuestEnabled 2>/dev/null)
[ "$GE2" != "1" ] && reassess "MAC-03" "양호" "게스트 꺼짐(조치 후)"
GK2=$(spctl --status 2>/dev/null)
case "$GK2" in *"assessments enabled"*) reassess "MAC-07" "양호" "Gatekeeper 켜짐(조치 후)";; esac
AC2=$(defaults read /Library/Preferences/com.apple.SoftwareUpdate AutomaticCheckEnabled 2>/dev/null)
CI2=$(defaults read /Library/Preferences/com.apple.SoftwareUpdate CriticalUpdateInstall 2>/dev/null)
AI2=$(defaults read /Library/Preferences/com.apple.SoftwareUpdate AutomaticallyInstallMacOSUpdates 2>/dev/null)
if [ "$AC2" = "1" ] && { [ "$CI2" = "1" ] || [ "$AI2" = "1" ]; }; then reassess "MAC-08" "양호" "자동 업데이트 켜짐(조치 후)"; fi
FW2=$($SUDO /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>/dev/null)
case "$FW2" in *"State = 1"*|*"State = 2"*) reassess "MAC-09" "양호" "방화벽 켜짐(조치 후)";; esac
if [ "$HAVE_SUDO" = "1" ]; then
  SSH2=$($SUDO systemsetup -getremotelogin 2>/dev/null)
  case "$SSH2" in *Off*) reassess "MAC-10" "양호" "SSH 꺼짐(조치 후)";; esac
fi
[ ! -e "/Library/Application Support/Apple/Remote Desktop/RemoteManagement.launchd" ] && reassess "MAC-11" "양호" "ARD 비활성화(조치 후)"
[ "${RECHG:-0}" = "0" ] && out "  변경 항목 없음 (이미 양호였거나 재로그인 후 반영)"
out ""
out "위에 '조치 전 -> 조치 후'로 표시된 항목이 이번에 조치된 것입니다. 아래 최종 요약은 조치 후 기준입니다."

# ---- 자동 조치하지 않은 항목 ----
out ""
out "[자동 조치하지 않은 항목] (권고 / 직접 / 담당자 판단)"
out "  · 권고  ─ FileVault 디스크 암호화(MAC-05) : 복구 키를 잃으면 데이터 잠김 — 권고로 둠"
out "  · 직접  ─ 인터넷 공유(MAC-13) / 나의 Mac 찾기(MAC-14) / Time Machine(MAC-15)"
out "  · 담당자─ SIP(MAC-06) / 파일 공유(MAC-12) / 관리자 계정(MAC-04) / 펌웨어(MAC-16)"

# ---- 최종 요약 + JSON ----
out ""
out "======================================================================"
out " 점검 :  양호 $PASS / 취약 $FAIL / 권고 $REC / 정보 $INFO"
out " 조치 :  적용 $APPLIED / 실패 $FAILED"
out " 결과 파일 : $REPORT"
out " 원복 파일 : $BACKUP  (실행하면 변경 전으로 되돌아감)"
out "======================================================================"
write_json
out " ▶ 다음 단계"
out "   1) 화면 잠금은 다음 로그인부터 확실히 적용됩니다. 한 번 로그아웃 권장."
out "   2) 위 '조치 후 재점검'에 최종 상태가 반영되어 있습니다(확인용으로 다시 실행하지 않아도 됨)."
out "   3) 문제가 생기면 원복 파일을 실행해 되돌리세요."

echo ""
echo "완료. 점검 양호 $PASS/취약 $FAIL/권고 $REC · 조치 적용 $APPLIED/실패 $FAILED"
echo "  결과: $REPORT"
echo "  JSON: $JSONPATH"
echo "이 창은 닫아도 됩니다."
