# Google Sheet 결과 수집 설정 (선택)

점검 결과를 여러 대에서 **본인 소유의 Google Sheet** 한 곳으로 모으고 싶을 때만 설정합니다. 이 단계를 건너뛰어도 점검·자동 조치·로컬 결과 저장(JSON/TXT)은 정상 동작합니다.

> 결과에는 호스트명·시리얼·IP·사용자 같은 **자산 정보**가 쌓입니다. 반드시 **본인이 직접 만든 시트**에 모으고, 공유 범위를 제한하세요. (이 저장소에는 어떤 수집 서버 주소도 들어 있지 않습니다.)

---

## A. 본인 Google Sheet + Apps Script 배포 (한 번만)

1. [sheets.google.com](https://sheets.google.com) 에서 새 시트를 만듭니다. (예: `Endpoint Security Check`)
2. 상단 메뉴 **확장 프로그램 → Apps Script** 를 엽니다.
3. 기존 코드를 모두 지우고, 이 저장소의 **`google_sheet_endpoint.gs`** 내용을 전부 붙여넣습니다.
4. (권장) 맨 위 `var SHARED_TOKEN = '';` 의 따옴표 안에 임의의 문자열을 넣습니다. 아무나 시트에 쓰지 못하게 막는 공유 암호 역할입니다.
   ```javascript
   var SHARED_TOKEN = 'your-secret-token';
   ```
5. 저장(디스크 아이콘)합니다.
6. 우측 상단 **배포 → 새 배포**:
   - 유형(톱니) → **웹 앱**
   - 실행 계정: **나**
   - 액세스 권한: **모든 사용자**
   - **배포** → 권한 승인(본인 Google 계정) → **웹 앱 URL** 복사
   - URL은 `https://script.google.com/macros/s/AKfyc.../exec` 형태입니다.

> 웹앱을 **'모든 사용자' 접근**으로 배포해야 각 단말에서 토큰만으로 전송됩니다. (개별 로그인 없이 전송하기 위함이며, 무단 전송은 `SHARED_TOKEN` 으로 차단합니다.)

---

## B. URL 넣기 — `sheet_config.txt` 만 수정 (스크립트는 편집 금지)

각 플랫폼 폴더(`windows/`, `macos/`)의 **`sheet_config.txt`** 를 텍스트 편집기로 열고, `SHEET_URL=` 바로 뒤(같은 줄)에 복사한 웹앱 URL을 붙여넣습니다. 토큰을 썼다면 `SHEET_TOKEN=` 뒤에 같은 값을 넣습니다.

```
SHEET_URL=https://script.google.com/macros/s/AKfyc...(본인 URL).../exec
SHEET_TOKEN=your-secret-token
```

이렇게 하면 더블클릭(`.bat`/`.command`)만으로 결과가 시트로 전송됩니다.

> ⚠️ **`win_sec.ps1` / `Mac_보안점검조치.command` 본체는 절대 편집·저장하지 마세요.** 편집기로 저장하면 한글(BOM/인코딩)이 깨져 다른 PC에서 실행 오류가 납니다. URL은 `sheet_config.txt` 에만 넣으세요.

---

## C. (대안) 명령줄로 URL 직접 전달

설정 파일 대신 실행 시 인자로 넘길 수도 있습니다(인자가 우선).

**Windows (관리자 PowerShell)**
```powershell
powershell -ExecutionPolicy Bypass -File win_sec.ps1 `
  -OwnerEmail "you@example.com" `
  -SheetUrl "복사한_웹앱_URL" `
  -SheetToken "your-secret-token"
```

**macOS (터미널)**
```bash
bash Mac_보안점검조치.command --email "you@example.com" \
     --sheet-url "복사한_웹앱_URL" --sheet-token "your-secret-token"
```

- `-OwnerEmail`/`--email` 생략 시 실행 중 한 번 묻고 `owner.txt` 에 저장합니다(다음부터 안 물음).
- `-SheetToken`/`--sheet-token` 은 A-4의 `SHARED_TOKEN` 과 같아야 기록됩니다.
- 점검만 하려면 `-CheckOnly`(Windows) / `--check-only`(macOS). 점검만 해도 시트에는 기록됩니다.

---

## 도구 버전 컬럼

`.gs` 는 결과의 `toolVersion` 값을 '점검결과' 탭 **맨 끝 '도구버전' 컬럼**에 기록합니다. 어느 PC가 어느 버전으로 점검했는지 추적할 수 있습니다.

> `.gs` 를 고친 뒤에는 **반드시 '새 버전'으로 다시 배포**해야 반영됩니다(배포 → 배포 관리 → 연필 → 새 버전 → 배포). 이때 `/exec` URL은 그대로라 `sheet_config.txt` 는 다시 안 바꿔도 됩니다.

---

## 시트에 안 들어갈 때 — 점검 순서

1. **토큰 일치 확인**: A-4에서 `SHARED_TOKEN` 에 값을 넣었다면, `sheet_config.txt`(또는 인자)의 `SHEET_TOKEN` 도 똑같아야 합니다. 다르면 거부되어 한 줄도 안 들어갑니다. 토큰을 안 쓸 거면 `.gs` 의 `SHARED_TOKEN = ''` 로 비웁니다.
2. **접근 권한 확인**: 웹앱 URL을 **시크릿 창(로그아웃 상태)** 으로 엽니다.
   - `{"ok":true,...}` 가 보이면 접근 OK → 원인은 1번 토큰일 가능성이 큽니다.
   - Google 로그인 페이지로 넘어가면 도메인 제한 배포입니다. 배포 → 배포 관리 → 연필 → 버전 '새 버전' → 액세스 권한 '모든 사용자' → 배포로 다시 배포하세요. (URL이 `/a/macros/<도메인>/...` 형태면 이 경우입니다.)
3. `.gs` 코드를 고친 뒤에는 반드시 **'새 버전'으로 다시 배포**해야 반영됩니다.
4. 조직 네트워크가 외부(`script.google.com`) 접속을 막으면 전송이 실패합니다. 그 경우 아래 로컬 엑셀 취합을 쓰세요(JSON은 항상 로컬에 저장됩니다).

---

## 주의 / 한계

- 시트에 자산 정보(호스트·시리얼·IP·사용자)가 쌓입니다. **시트 공유는 특정 인원으로 제한**하세요(링크 공개 금지). 무단 전송은 `SHARED_TOKEN` 으로 차단합니다.
- "누구 PC인지"는 **담당자 이메일** 칸으로 식별합니다. Windows 로그인이 Google 계정과 연동돼 있지 않으면 이메일 자동 인식이 어려워, 실행 중 입력/캐시 방식을 씁니다.

---

## 로컬에서 엑셀로 취합 (Google Sheet 없이)

시트를 안 쓰거나 외부 전송이 막혔다면, 각 PC의 JSON을 모아 엑셀 한 장으로 합칠 수 있습니다.

1. 각 PC에서 생긴 `WinSec_*.json` / `MacSec_*.json` 을 한 폴더에 모읍니다.
2. 그 폴더에서:
   ```bash
   pip install openpyxl
   python3 aggregate_to_excel.py
   ```
3. `보안점검_통합_<날짜>.xlsx` 가 생성됩니다(시트: 요약 / 항목별 / 조치내역). 이 엑셀을 Google Drive에 올려 시트로 열어도 됩니다.
