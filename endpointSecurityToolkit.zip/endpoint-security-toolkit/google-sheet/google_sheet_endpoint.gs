/**
 * WinSec/MacSec -> Google Sheet 수집 엔드포인트 (Apps Script)
 *  - '점검결과' 탭 : PC당 1행 요약 (하드웨어 + 취약·권고 항목 + 자동 조치 내역)
 *  - '상세'     탭 : 취약·권고 항목과 조치 내역을 항목별 1행으로 기록
 * 설정 방법은 SETUP_구글시트.txt 참고.
 */
var SHARED_TOKEN = '';  // 스크립트의 SheetToken / SHEET_TOKEN 과 동일하게. 비우면 토큰 검사 안 함(권장: 임의 문자열)

function doPost(e) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(30000); } catch (x) {}
  try {
    var data = JSON.parse(e.postData.contents);
    if (SHARED_TOKEN && String(data.token || '') !== SHARED_TOKEN) {
      return _json({ ok: false, error: 'invalid token' });
    }
    var ss   = SpreadsheetApp.getActiveSpreadsheet();
    var now  = new Date();
    var pc   = data.pc || {}, s = data.summary || {};
    var items = data.items || [], rem = data.remediation || [];

    var findings = [], applied = [];
    for (var i = 0; i < items.length; i++) {
      var r = items[i].result;
      if (r === '취약' || r === '권고') {
        findings.push('[' + r + '] ' + (items[i].title || items[i].id || ''));
      }
    }
    for (var j = 0; j < rem.length; j++) {
      if (rem[j].status === '적용') applied.push(rem[j].text || '');
    }

    var sh = ss.getSheetByName('점검결과');
    if (!sh) { sh = ss.insertSheet('점검결과'); }
    if (sh.getLastRow() === 0) {
      sh.appendRow(['수집시각','담당자이메일','호스트','사용자','제조사','모델','시리얼',
                    'CPU','RAM(GB)','디스크(GB)','여유(GB)','OS','에디션','제조일',
                    'IP','MAC','양호','취약','권고','정보','조치적용','조치실패',
                    '취약·권고 항목','자동 조치 내역','기록시각','도구버전']);
      sh.setFrozenRows(1);
    }
    sh.appendRow([data.collectedAt||'', data.ownerEmail||'', pc.hostname||'', pc.user||'',
                  pc.manufacturer||'', pc.model||'', pc.serial||'',
                  pc.cpu||'', pc.ramGB||'', pc.diskGB||'', pc.freeGB||'',
                  pc.os||'', pc.edition||'', pc.mfgDate||'',
                  pc.ip||'', pc.mac||'', s.pass||0, s.vuln||0, s.rec||0, s.info||0,
                  s.applied||0, s.failed||0,
                  findings.join('\n'), applied.join('\n'), now, data.toolVersion||'']);

    var d = ss.getSheetByName('상세');
    if (!d) { d = ss.insertSheet('상세'); }
    if (d.getLastRow() === 0) {
      d.appendRow(['기록시각','담당자이메일','호스트','구분','ID','항목/조치내용','결과/상태','근거/설명']);
      d.setFrozenRows(1);
    }
    var rows = [];
    for (var k = 0; k < items.length; k++) {
      var rr = items[k].result;
      if (rr === '취약' || rr === '권고') {
        rows.push([now, data.ownerEmail||'', pc.hostname||'', rr,
                   items[k].id||'', items[k].title||'', rr, items[k].evidence||'']);
      }
    }
    for (var m = 0; m < rem.length; m++) {
      if (rem[m].status === '적용' || rem[m].status === '실패') {
        rows.push([now, data.ownerEmail||'', pc.hostname||'', '조치',
                   '', rem[m].text||'', rem[m].status||'', '']);
      }
    }
    if (rows.length > 0) {
      d.getRange(d.getLastRow() + 1, 1, rows.length, 8).setValues(rows);
    }

    return _json({ ok: true, findings: findings.length, applied: applied.length, detailRows: rows.length });
  } catch (err) {
    return _json({ ok: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}

function doGet() { return _json({ ok: true, msg: 'WinSec endpoint alive' }); }
function _json(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
