#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WinSec 결과 취합기
  - 여러 PC가 만든 WinSec_*.json 을 한 폴더에 모아두고 이 스크립트를 실행하면
    통합 엑셀(보안점검_통합_<날짜>.xlsx)로 정리합니다.
  - 사용법:  python aggregate_to_excel.py [JSON폴더]   (생략 시 현재 폴더)
  - 필요:    pip install openpyxl
"""
import sys, os, glob, json, datetime

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("openpyxl 이 필요합니다.  명령창에서:  pip install openpyxl")
    sys.exit(1)

folder = sys.argv[1] if len(sys.argv) > 1 else "."
files = sorted(glob.glob(os.path.join(folder, "WinSec_*.json")) + glob.glob(os.path.join(folder, "MacSec_*.json")))
if not files:
    print(f"'{folder}' 에서 WinSec_*.json / MacSec_*.json 파일을 찾지 못했습니다.")
    sys.exit(1)

records = []
for f in files:
    try:
        with open(f, encoding="utf-8-sig") as fp:   # PowerShell JSON 은 BOM 포함
            records.append(json.load(fp))
    except Exception as e:
        print(f"  [건너뜀] {os.path.basename(f)} : {e}")

if not records:
    print("읽을 수 있는 JSON 이 없습니다.")
    sys.exit(1)

# ---- 색상 ----
RESULT_FILL = {
    "취약": PatternFill("solid", fgColor="F4CCCC"),
    "권고": PatternFill("solid", fgColor="FCE5CD"),
    "양호": PatternFill("solid", fgColor="D9EAD3"),
    "정보": PatternFill("solid", fgColor="EFEFEF"),
}
HEAD_FILL = PatternFill("solid", fgColor="1F2A44")
HEAD_FONT = Font(color="FFFFFF", bold=True, size=10)
THIN = Side(style="thin", color="D0D0D0")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
CENTER = Alignment(horizontal="center", vertical="center")
WRAP = Alignment(vertical="top", wrap_text=True)


def style_header(ws, ncol):
    for c in range(1, ncol + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HEAD_FILL; cell.font = HEAD_FONT
        cell.alignment = CENTER; cell.border = BORDER
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ncol)}1"


def set_widths(ws, widths):
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


wb = Workbook()

# ===================== 1) 요약 =====================
ws = wb.active; ws.title = "요약"
head = ["담당자이메일", "호스트", "사용자", "제조사", "모델", "시리얼",
        "CPU", "RAM(GB)", "디스크(GB)", "여유(GB)",
        "OS", "에디션", "제조일", "IP", "MAC", "마지막부팅", "설치일",
        "양호", "취약", "권고", "정보", "조치적용", "조치실패", "수집시각"]
ws.append(head)
for r in records:
    pc = r.get("pc", {}); s = r.get("summary", {})
    ws.append([
        r.get("ownerEmail", ""), pc.get("hostname", ""), pc.get("user", ""),
        pc.get("manufacturer", ""), pc.get("model", ""), pc.get("serial", ""),
        pc.get("cpu", ""), pc.get("ramGB", ""), pc.get("diskGB", ""), pc.get("freeGB", ""),
        pc.get("os", ""), pc.get("edition", ""), pc.get("mfgDate", ""),
        pc.get("ip", ""), pc.get("mac", ""), pc.get("lastBoot", ""), pc.get("installDate", ""),
        s.get("pass", 0), s.get("vuln", 0), s.get("rec", 0), s.get("info", 0),
        s.get("applied", 0), s.get("failed", 0), r.get("collectedAt", ""),
    ])
style_header(ws, len(head))
set_widths(ws, [26, 14, 12, 16, 22, 16, 22, 8, 10, 10, 22, 9, 12, 14, 18, 18, 12, 6, 6, 6, 6, 8, 8, 20])
# 취약>0 빨강, 권고>0 주황, 조치실패>0 빨강 강조
for row in range(2, ws.max_row + 1):
    v = ws.cell(row=row, column=19).value or 0      # 취약
    rec = ws.cell(row=row, column=20).value or 0    # 권고
    fail = ws.cell(row=row, column=23).value or 0   # 조치실패
    if v and int(v) > 0:
        ws.cell(row=row, column=19).fill = RESULT_FILL["취약"]; ws.cell(row=row, column=19).font = Font(bold=True, color="CC0000")
    if rec and int(rec) > 0:
        ws.cell(row=row, column=20).fill = RESULT_FILL["권고"]
    if fail and int(fail) > 0:
        ws.cell(row=row, column=23).fill = RESULT_FILL["취약"]; ws.cell(row=row, column=23).font = Font(bold=True, color="CC0000")
    for c in range(1, len(head) + 1):
        ws.cell(row=row, column=c).border = BORDER
        if c >= 18:
            ws.cell(row=row, column=c).alignment = CENTER

# ===================== 2) 항목별 =====================
ws2 = wb.create_sheet("항목별")
head2 = ["호스트", "담당자이메일", "ID", "항목", "결과", "근거", "기준", "조치"]
ws2.append(head2)
for r in records:
    pc = r.get("pc", {})
    for it in r.get("items", []):
        ws2.append([
            pc.get("hostname", ""), r.get("ownerEmail", ""),
            it.get("id", ""), it.get("title", ""), it.get("result", ""),
            it.get("evidence", ""), it.get("basis", ""), it.get("action", ""),
        ])
style_header(ws2, len(head2))
set_widths(ws2, [14, 24, 10, 22, 8, 34, 40, 50])
for row in range(2, ws2.max_row + 1):
    res = ws2.cell(row=row, column=5).value
    fill = RESULT_FILL.get(res)
    if fill:
        ws2.cell(row=row, column=5).fill = fill
        ws2.cell(row=row, column=5).alignment = CENTER
    for c in range(1, len(head2) + 1):
        ws2.cell(row=row, column=c).border = BORDER
        if c in (6, 7, 8):
            ws2.cell(row=row, column=c).alignment = WRAP

# ===================== 3) 조치내역 =====================
ws3 = wb.create_sheet("조치내역")
head3 = ["호스트", "담당자이메일", "상태", "조치 내용"]
ws3.append(head3)
for r in records:
    pc = r.get("pc", {})
    for fx in r.get("remediation", []):
        ws3.append([pc.get("hostname", ""), r.get("ownerEmail", ""),
                    fx.get("status", ""), fx.get("text", "")])
style_header(ws3, len(head3))
set_widths(ws3, [14, 24, 8, 70])
for row in range(2, ws3.max_row + 1):
    st = ws3.cell(row=row, column=3).value
    if st == "적용":
        ws3.cell(row=row, column=3).fill = RESULT_FILL["양호"]
    elif st == "실패":
        ws3.cell(row=row, column=3).fill = RESULT_FILL["취약"]
    ws3.cell(row=row, column=3).alignment = CENTER
    for c in range(1, len(head3) + 1):
        ws3.cell(row=row, column=c).border = BORDER

out = os.path.join(folder, f"보안점검_통합_{datetime.date.today():%Y%m%d}.xlsx")
wb.save(out)
print(f"완료: {out}")
print(f"  PC {len(records)}대  /  항목 {ws2.max_row - 1}행  /  조치 {ws3.max_row - 1}행")
print(f"  시트: 요약 · 항목별 · 조치내역")
